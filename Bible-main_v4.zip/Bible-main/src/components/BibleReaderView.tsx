import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Monitor,
  Search,
  Volume2,
  VolumeX,
  ArrowDown,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Heart,
  X,
  Sun,
  Moon,
  Mic,
  Share2,
  Check,
} from 'lucide-react';
import {
  BIBLE_BOOKS,
  SAMPLE_VERSES_CHAPTER,
  getChapterVerseCount,
  getCompletedVerses,
  getCompletedChapters,
  isChapterFullyRead,
  toggleVerseCompleted,
  toggleChapterVersesCompleted,
  markChapterVersesCompleted,
  markChapterRangeCompleted,
  saveCurrentReadingLocation,
  addTodayReadChapter,
} from '../data/bibleData';
import { BibleVerse } from '../types';
import { BibleSelectorModal } from './BibleSelectorModal';
import { AudioShareModal, AudioShareData } from './AudioShareModal';
import {
  updateMemberReadingProgress,
  getActiveSession,
  addMemberRecordingToAdmin,
} from '../services/authService';
import { convertBlobToMp3 } from '../utils/audioToMp3';
import { saveAudioToStorage } from '../utils/audioStorage';
import {
  loadBibleChapterVerses,
  getAllAvailableTranslations,
  isCustomTranslationRegistered,
  TranslationOption,
} from '../services/bibleApiService';
import { CustomBibleUploadModal } from './CustomBibleUploadModal';

interface BibleReaderViewProps {
  onOpenVerseCard: (verse: BibleVerse) => void;
  onOpenRecorder: (verse: BibleVerse) => void;
  initialBook?: string;
  initialChapter?: number;
  initialVerse?: number;
  initialRecordingMode?: boolean;
  onBack?: () => void;
  onBackToHome?: () => void;
  onGoToChallenge?: () => void;
  onBackToSelector?: () => void;
}

// Fallback inspiring Scripture pool without redundant book/chapter/verse announcement prefix
const FALLBACK_SCRIPTURES = [
  '주의 말씀은 내 발에 등이요 내 길에 빛이니이다.',
  '여호와는 나의 목자시니 내게 부족함이 없으리로다 그가 나를 푸른 풀밭에 누이시며 쉴 만한 물 가로 인도하시는도다.',
  '내가 산을 향하여 눈을 들리라 나의 도움이 어디서 올까 나의 도움은 천지를 지으신 여호와에게서로다.',
  '하나님이 세상을 이처럼 사랑하사 독생자를 주셨으니 이는 그를 믿는 자마다 멸망하지 않고 영생을 얻게 하려 하심이라.',
  '우리가 알거니와 하나님을 사랑하는 자 곧 그의 뜻대로 부르심을 입은 자들에게는 모든 것이 합력하여 선을 이루느니라.',
  '너는 마음을 다하여 여호와를 신뢰하고 네 명철을 의지하지 말라 너는 범사에 그를 인정하라 그리하면 네 길을 지도하시리라.',
  '오직 여호와를 앙망하는 자는 새 힘을 얻으리니 독수리가 날개치며 올라감 같을 것이요 달음박질하여도 곤비하지 아니하겠고 걸어가도 피곤하지 아니하리로다.',
  '내게 능력 주시는 자 안에서 내가 모든 것을 할 수 있느니라.',
  '아무 것도 염려하지 말고 다만 모든 일에 기도와 간구로, 너희 구할 것을 감사함으로 하나님께 아뢰라 그리하면 모든 지각에 뛰어난 하나님의 평강이 그리스도 예수 안에서 너희 마음과 생각을 지키시리라.',
  '여호와는 나의 빛이요 나의 구원이시니 내가 누구를 두려워하리요 여호와는 내 생명의 능력이시니 내가 누구를 무서워하리요.',
  '너희는 먼저 그의 나라와 그의 의를 구하라 그리하면 이 모든 것을 너희에게 더하시리라.',
  '평안을 너희에게 끼치노니 곧 나의 평안을 너희에게 주노라 내가 너희에게 주는 것은 세상이 주는 것과 같지 아니하니라 너희는 마음에 근심하지도 말고 두려워하지도 말라.',
  '여호와를 경외하는 것이 지혜의 근본이요 거룩하신 자를 아는 것이 명철이니라.',
  '믿음은 바라는 것들의 실상이요 보이지 않는 것들의 증거니 선진들이 이로써 증거를 얻었느니라.',
  '사랑은 오래 참고 사랑은 온유하며 시기하지 아니하며 사랑은 자랑하지 아니하며 교만하지 아니하며 무례히 행하지 아니하며 자기의 유익을 구하지 아니하며.',
  '두려워하지 말라 내가 너와 함께 함이라 놀라지 말라 나는 네 하나님이 됨이라 내가 너를 굳세게 하리라 참으로 너를 도와 주리라 참으로 나의 의로운 오른손으로 너를 붙들리라.',
  '수고하고 무거운 짐 진 자들아 다 내게로 오라 내가 너희를 쉬게 하리라.',
  '오직 성령의 열매는 사랑과 희락과 화평과 오래 참음과 자비와 양선과 충성과 온유와 절제니 이같은 것을 금지할 법이 없느니라.',
  '구하라 그리하면 너희에게 주실 것이요 찾으라 그리하면 찾아낼 것이요 문을 두드리라 그리하면 너희에게 열릴 것이니.',
  '풀은 마르고 꽃은 시드나 우리 하나님의 말씀은 영원히 서리라 하라.',
];

export interface VoiceProfile {
  voice: SpeechSynthesisVoice | null;
  pitch: number;
  rate: number;
  pauseMs: number;
  engineName: string;
  summary: string;
  isNatural?: boolean;
}

// 긴 구절 분할 (구글 음성 스트림 안정성 보장)
const splitLongText = (text: string, maxLen = 140): string[] => {
  if (text.length <= maxLen) return [text];
  const parts: string[] = [];
  const sentences = text.split(/([.,!?;\n]+)/);
  let current = '';
  for (let i = 0; i < sentences.length; i++) {
    const s = sentences[i];
    if ((current + s).length > maxLen) {
      if (current.trim()) parts.push(current.trim());
      current = s;
    } else {
      current += s;
    }
  }
  if (current.trim()) parts.push(current.trim());
  return parts.length > 0 ? parts : [text.slice(0, maxLen), text.slice(maxLen)];
};

// 기계음 없는 100% 자연 육성 오디오 스트림 재생기 (Google Neural)
const playNeuralAudio = (
  text: string,
  rate: number,
  onEnd: () => void,
  onError: () => void,
  lang: 'ko' | 'en' = 'ko'
): { pause: () => void } => {
  const chunks = splitLongText(text, 140);
  let chunkIdx = 0;
  let currentAudio: HTMLAudioElement | null = null;
  let isCancelled = false;

  const playNextChunk = () => {
    if (isCancelled) return;
    if (chunkIdx >= chunks.length) {
      onEnd();
      return;
    }
    const chunk = chunks[chunkIdx];
    chunkIdx++;
    // 영어(NIV/KJV)는 원어 발음(en-US)으로 요청하여 기계음/어색한 발음 완전 배제
    const targetLang = lang === 'en' ? 'en-US' : 'ko';
    const url = `https://translate.google.com/translate_tts?ie=UTF-8&tl=${targetLang}&client=tw-ob&q=${encodeURIComponent(chunk)}`;
    currentAudio = new Audio(url);
    currentAudio.playbackRate = Math.min(2.0, Math.max(0.7, rate));
    currentAudio.onended = () => {
      if (!isCancelled) playNextChunk();
    };
    currentAudio.onerror = (e) => {
      console.warn('Neural audio stream error', e);
      if (!isCancelled) onError();
    };
    currentAudio.play().catch((err) => {
      console.warn('Audio play error', err);
      if (!isCancelled) onError();
    });
  };

  playNextChunk();
  return {
    pause: () => {
      isCancelled = true;
      if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
      }
    },
  };
};

const playNeuralFemaleAudio = playNeuralAudio;

export const getVoiceProfile = (
  type: string,
  voices: SpeechSynthesisVoice[],
  baseRate: number = 1.1,
  userPitch: number = 0.96,
  isEnglish: boolean = false
): VoiceProfile => {
  // ----------------------------------------------------
  // 1. 영어 낭독 (NIV / 영문 성경): 기계음 완전 차단 & 고음질 원음 선별
  // ----------------------------------------------------
  if (isEnglish) {
    const enVoices = (voices || []).filter((v) =>
      v.lang.toLowerCase().startsWith('en')
    );

    // 구형 기계음 데스크톱 SAPI 보이스(Microsoft David Desktop, Zira Desktop 등) 배제
    const isRoboticSapiEn = (v: SpeechSynthesisVoice) => {
      const n = v.name.toLowerCase();
      return n.includes('desktop') || n.includes('sapi');
    };

    const isNaturalEn = (v: SpeechSynthesisVoice) => {
      const n = v.name.toLowerCase();
      const uri = (v.voiceURI || '').toLowerCase();
      return (
        n.includes('natural') ||
        n.includes('online') ||
        n.includes('neural') ||
        n.includes('google') ||
        n.includes('samantha') ||
        n.includes('jenny') ||
        n.includes('aria') ||
        n.includes('guy') ||
        n.includes('daniel') ||
        uri.includes('natural') ||
        uri.includes('neural')
      );
    };

    const isMaleEn = (v: SpeechSynthesisVoice) => {
      const n = v.name.toLowerCase();
      return (
        n.includes('guy') ||
        n.includes('ryan') ||
        n.includes('daniel') ||
        n.includes('male') ||
        n.includes('man') ||
        n.includes('david') ||
        n.includes('george')
      );
    };

    const isFemaleEn = (v: SpeechSynthesisVoice) => {
      if (isMaleEn(v)) return false;
      const n = v.name.toLowerCase();
      return (
        n.includes('jenny') ||
        n.includes('aria') ||
        n.includes('michelle') ||
        n.includes('samantha') ||
        n.includes('karen') ||
        n.includes('female') ||
        n.includes('woman') ||
        n.includes('girl') ||
        !isMaleEn(v)
      );
    };

    // 영어 낭독 최적 템포 (한국어보다 살짝 차분한 0.95~1.0x가 가장 자연스러움)
    const effectiveRate = Math.min(1.05, Math.max(0.85, baseRate * 0.92));

    if (type.includes('여성')) {
      const naturalFemale = enVoices.find(
        (v) => isFemaleEn(v) && isNaturalEn(v) && !isRoboticSapiEn(v)
      );

      if (naturalFemale) {
        return {
          voice: naturalFemale,
          pitch: 1.0,
          rate: effectiveRate,
          pauseMs: 70,
          engineName: naturalFemale.name,
          summary: '기계음 없는 100% 맑고 자연스러운 영어(NIV) 여성 육성 낭독입니다.',
          isNatural: true,
        };
      }

      // 브라우저에 자연스러운 영어 음성이 없으면 Google Natural English Stream으로 재생
      const anyFemale = enVoices.find((v) => isFemaleEn(v) && !isRoboticSapiEn(v)) || null;
      return {
        voice: anyFemale,
        pitch: 1.0,
        rate: effectiveRate,
        pauseMs: 70,
        engineName: 'AI 스튜디오 자연 영어 음원 (Google Natural English)',
        summary: '기계음 없는 100% 자연스럽고 유창한 영어(NIV) 원음 낭독입니다.',
        isNatural: false,
      };
    }

    // 남성 / 목회자
    const naturalMale = enVoices.find(
      (v) => isMaleEn(v) && isNaturalEn(v) && !isRoboticSapiEn(v)
    );
    if (naturalMale) {
      return {
        voice: naturalMale,
        pitch: 0.98,
        rate: effectiveRate,
        pauseMs: 80,
        engineName: naturalMale.name,
        summary: '중후하고 신뢰감 있는 자연스러운 영어(NIV) 남성 육성 낭독입니다.',
        isNatural: true,
      };
    }

    const anyMale = enVoices.find((v) => isMaleEn(v) && !isRoboticSapiEn(v)) || null;
    return {
      voice: anyMale,
      pitch: 0.98,
      rate: effectiveRate,
      pauseMs: 80,
      engineName: anyMale ? anyMale.name : 'AI 스튜디오 자연 영어 음원 (Google Natural English)',
      summary: '기계음 없는 100% 자연스러운 영어(NIV) 원음 낭독입니다.',
      isNatural: anyMale ? !isRoboticSapiEn(anyMale) : false,
    };
  }

  // ----------------------------------------------------
  // 2. 한국어 낭독: 기계음 차단 및 자연 육성 엔진 매핑
  // ----------------------------------------------------
  const koVoices = (voices || []).filter(
    (v) => v.lang.toLowerCase().includes('ko') || v.lang.toLowerCase().includes('kr')
  );

  // 구형 기계음 SAPI 보이스(Microsoft Heami Desktop 등) 확인
  const isRoboticSapi = (v: SpeechSynthesisVoice) => {
    const n = v.name.toLowerCase();
    return n.includes('heami') || n.includes('혜미') || n.includes('desktop');
  };

  const isNatural = (v: SpeechSynthesisVoice) => {
    const n = v.name.toLowerCase();
    const uri = (v.voiceURI || '').toLowerCase();
    return (
      n.includes('natural') ||
      n.includes('online') ||
      n.includes('neural') ||
      n.includes('google') ||
      n.includes('apple') ||
      uri.includes('natural') ||
      uri.includes('neural')
    );
  };

  const isMale = (v: SpeechSynthesisVoice) => {
    const n = v.name.toLowerCase();
    const uri = (v.voiceURI || '').toLowerCase();
    return (
      n.includes('injoon') ||
      n.includes('in-joon') ||
      n.includes('in joon') ||
      n.includes('인준') ||
      n.includes('bongjin') ||
      n.includes('bong-jin') ||
      n.includes('봉진') ||
      n.includes('sinji') ||
      n.includes('신지') ||
      n.includes('male') ||
      n.includes('man') ||
      n.includes('남성') ||
      n.includes('boy') ||
      uri.includes('injoon')
    );
  };

  const isFemale = (v: SpeechSynthesisVoice) => {
    if (isMale(v)) return false;
    const n = v.name.toLowerCase();
    return (
      n.includes('sunhi') ||
      n.includes('sun-hi') ||
      n.includes('sun hi') ||
      n.includes('선희') ||
      n.includes('yuna') ||
      n.includes('yu-na') ||
      n.includes('유나') ||
      n.includes('sora') ||
      n.includes('소라') ||
      n.includes('seoyeon') ||
      n.includes('서연') ||
      n.includes('ji-min') ||
      n.includes('jimin') ||
      n.includes('지민') ||
      n.includes('so-hee') ||
      n.includes('sohee') ||
      n.includes('소희') ||
      n.includes('hyon-sim') ||
      n.includes('hyonsim') ||
      n.includes('현심') ||
      n.includes('female') ||
      n.includes('woman') ||
      n.includes('girl') ||
      n.includes('google') ||
      !isMale(v)
    );
  };

  // 1. 여성 선택 시 (절대 남성 음성 혼입 금지 / 기계음 차단)
  if (type.includes('여성')) {
    // 1순위: 브라우저 고음질 뉴럴 여성 보이스 (Edge SunHi Online Natural / Google 한국어 / Apple Yuna 등)
    const naturalFemale = koVoices.find(
      (v) => isFemale(v) && !isMale(v) && isNatural(v) && !isRoboticSapi(v)
    );

    if (naturalFemale) {
      return {
        voice: naturalFemale,
        pitch: 1.0, // 왜곡 없는 자연스러운 100% 여성 원음
        rate: baseRate,
        pauseMs: 60,
        engineName: naturalFemale.name,
        summary: '기계음 왜곡 없는 100% 맑고 자연스러운 여성 육성 낭독입니다.',
        isNatural: true,
      };
    }

    // 2순위: 브라우저에 구형 기계음(Heami)만 있거나 뉴럴 보이스가 없는 환경
    // AI 스튜디오 자연 여성 음원(Google Neural Female Audio)으로 낭독하여 기계음을 100% 차단!
    const anyFemale = koVoices.find((v) => isFemale(v) && !isMale(v)) || null;
    return {
      voice: anyFemale,
      pitch: 1.0,
      rate: baseRate,
      pauseMs: 60,
      engineName: 'AI 스튜디오 자연 여성 음원 (Google Neural)',
      summary: '기계음 없는 100% 자연스럽고 은혜로운 여성 육성 낭독입니다.',
      isNatural: false,
    };
  }

  // 2. 남성 (자연스러운 중저음):
  const naturalMale = koVoices.find((v) => isMale(v) && isNatural(v));
  const anyNonRoboticMale = naturalMale || koVoices.find((v) => isMale(v) && !isRoboticSapi(v));
  const voice = naturalMale || anyNonRoboticMale || koVoices.find((v) => isMale(v)) || koVoices[0] || null;

  return {
    voice,
    pitch: userPitch || 0.96, // 깊고 편안한 자연스러운 중저음 바리톤
    rate: baseRate,
    pauseMs: 60,
    engineName: voice ? voice.name : '한국어 고음질 자연어 엔진',
    summary: '기계음 없이 깊고 따뜻한 울림의 편안한 자연스러운 중저음(바리톤)입니다.',
    isNatural: voice ? isNatural(voice) : true,
  };
};

export const BibleReaderView: React.FC<BibleReaderViewProps> = ({
  onOpenVerseCard,
  onOpenRecorder,
  initialBook = '창세기',
  initialChapter = 1,
  initialVerse = 1,
  initialRecordingMode = false,
  onBack,
  onBackToHome,
  onGoToChallenge,
  onBackToSelector,
}) => {
  const [selectedBook, setSelectedBook] = useState(initialBook);
  const [selectedChapter, setSelectedChapter] = useState(initialChapter);
  const [selectedVerse, setSelectedVerse] = useState(initialVerse);
  const [selectedTranslation, setSelectedTranslation] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('superbible_selected_translation');
      if (saved && saved !== '새번역' && saved !== '직역성경') return saved;
    } catch (e) {}
    return '개역개정';
  });
  const [availableTranslations, setAvailableTranslations] = useState<TranslationOption[]>(() =>
    getAllAvailableTranslations()
  );
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [targetUploadVersion, setTargetUploadVersion] = useState('킹제임스흠정역');

  // Screen display settings (matching user uploaded screenshot)
  const [fontFamily, setFontFamily] = useState<'기본' | '나눔고딕' | '나눔명조'>('기본');
  const [isBold, setIsBold] = useState(false);
  const [fontSizePt, setFontSizePt] = useState(17);
  const [scrollSpeed, setScrollSpeed] = useState(13);
  const [isInverted, setIsInverted] = useState(false);

  // Audio state - 자연스러운 중저음 기본 활성화
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(186); // 03:06
  const [voiceType, setVoiceType] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('superbible_voice_type');
      if (saved && saved.includes('여성')) {
        return '여성 (맑고 자연스러운 음성)';
      }
    } catch (e) {}
    return '남성 (자연스러운 중저음)';
  });

  // Natural Korean TTS Speech Synthesis
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [speechRate, setSpeechRate] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('superbible_speech_rate');
      if (saved) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && parsed >= 0.7 && parsed <= 2.0) return parsed;
      }
    } catch (e) {}
    return 1.1; // 시원하고 경쾌한 1.1x 빠른 낭독 속도 (기본값)
  });
  const [speechPitch, setSpeechPitch] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('superbible_speech_pitch');
      if (saved) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && parsed >= 0.7 && parsed <= 1.5) return parsed;
      }
    } catch (e) {}
    return 0.96; // 부드럽고 자연스러운 중저음 톤 (0.96)
  });
  const [currentSpeakingVerse, setCurrentSpeakingVerse] = useState<number | null>(null);
  const [isPreviewPlaying, setIsPreviewPlaying] = useState<boolean>(false);

  const isPlayingRef = useRef(false);
  const currentVerseIndexRef = useRef(0);
  const speechRateRef = useRef(speechRate);
  const speechPitchRef = useRef(speechPitch);
  const voiceTypeRef = useRef(voiceType);
  const currentAudioRef = useRef<{ pause: () => void } | null>(null);

  useEffect(() => {
    speechRateRef.current = speechRate;
  }, [speechRate]);

  useEffect(() => {
    speechPitchRef.current = speechPitch;
  }, [speechPitch]);

  useEffect(() => {
    voiceTypeRef.current = voiceType;
  }, [voiceType]);

  // Load and cache browser/system speech synthesis voices
  useEffect(() => {
    if (!('speechSynthesis' in window)) return;

    const loadVoices = () => {
      const list = window.speechSynthesis.getVoices();
      if (list && list.length > 0) {
        setAvailableVoices(list);
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // When changing chapter or book, clean up any active playback
  useEffect(() => {
    return () => {
      isPlayingRef.current = false;
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [selectedBook, selectedChapter]);

  // Smooth scroll current speaking verse into center view
  useEffect(() => {
    if (currentSpeakingVerse !== null && isPlaying) {
      const el = document.getElementById(`verse-row-${currentSpeakingVerse}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [currentSpeakingVerse, isPlaying]);

  // Bible Reading Recording Mode (성경낭독녹음 모드 - matching user uploaded screenshot)
  const [isRecordingMode, setIsRecordingMode] = useState(initialRecordingMode);
  const [activeRecordVerse, setActiveRecordVerse] = useState<number>(initialVerse || 1);
  const [isRecordingNow, setIsRecordingNow] = useState(false);
  const [recordDurationSec, setRecordDurationSec] = useState(0);
  const [isContinuousRecording, setIsContinuousRecording] = useState(true);
  const [recordedVerses, setRecordedVerses] = useState<number[]>([]);
  const [showShareModal, setShowShareModal] = useState(false);
  const [activeShareData, setActiveShareData] = useState<AudioShareData | null>(null);

  // 낭독한 장 범위 (시작 장 ~ 마지막 낭독한 장, 예: 말라기 1~5장)
  const [recordStartChapter, setRecordStartChapter] = useState<number>(initialChapter);
  const [recordEndChapter, setRecordEndChapter] = useState<number>(initialChapter);

  // When selectedChapter changes, update recordEndChapter if newly visited is higher
  useEffect(() => {
    setRecordEndChapter((prev) => Math.max(prev, selectedChapter));
  }, [selectedChapter]);

  // When selectedBook changes, reset start & end chapter to selectedChapter
  useEffect(() => {
    setRecordStartChapter(selectedChapter);
    setRecordEndChapter(selectedChapter);
  }, [selectedBook]);

  const getBookMaxChapters = (bookName: string): number => {
    const found = BIBLE_BOOKS.find((b) => b.name === bookName);
    return found ? found.chaptersCount : 50;
  };

  const getFormattedPassage = (book: string, startCh: number, endCh: number): string => {
    const min = Math.min(startCh, endCh);
    const max = Math.max(startCh, endCh);
    return min === max ? `${book} ${min}장` : `${book} ${min}~${max}장`;
  };

  // Real Audio Capture for Recording Mode (MediaRecorder)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordedBlobRef = useRef<Blob | null>(null);
  const recordedUrlRef = useRef<string | null>(null);

  useEffect(() => {
    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      if (recordedUrlRef.current) {
        URL.revokeObjectURL(recordedUrlRef.current);
      }
    };
  }, []);

  // UI Modals
  const [showSelectorModal, setShowSelectorModal] = useState(false);
  const [selectorInitialStep, setSelectorInitialStep] = useState<'book' | 'chapter' | 'verse'>('book');
  const [showTransModal, setShowTransModal] = useState(false);
  const [showScreenSettings, setShowScreenSettings] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showOfferingModal, setShowOfferingModal] = useState(false);
  const [showVoiceModal, setShowVoiceModal] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [highlightedVerses, setHighlightedVerses] = useState<number[]>([]);

  // 성경 읽기 완료된 절 및 장 관리 상태
  const [completedVerses, setCompletedVerses] = useState<Set<string>>(() => getCompletedVerses());
  const [completedChapters, setCompletedChapters] = useState<Set<string>>(() => getCompletedChapters());

  useEffect(() => {
    const handleVerseChanged = () => {
      setCompletedVerses(getCompletedVerses());
      setCompletedChapters(getCompletedChapters());
    };
    window.addEventListener('superbible_verse_read_changed', handleVerseChanged);
    return () => {
      window.removeEventListener('superbible_verse_read_changed', handleVerseChanged);
    };
  }, []);

  const contentRef = useRef<HTMLDivElement>(null);

  // Sync with prop changes
  useEffect(() => {
    setSelectedBook(initialBook);
    setSelectedChapter(initialChapter);
    setSelectedVerse(initialVerse);
    setActiveRecordVerse(initialVerse || 1);
  }, [initialBook, initialChapter, initialVerse]);

  // Save current active reading location in real time
  useEffect(() => {
    if (selectedBook && selectedChapter) {
      saveCurrentReadingLocation(selectedBook, selectedChapter);
    }
  }, [selectedBook, selectedChapter]);

  // Generate or fetch verses (defined BEFORE any derived counts to prevent temporal dead zone ReferenceError!)
  const key = `${selectedBook}-${selectedChapter}`;
  const [apiVerses, setApiVerses] = useState<{ verse: number; text: string }[] | null>(null);
  const [isLoadingVerses, setIsLoadingVerses] = useState<boolean>(false);

  useEffect(() => {
    let isCancelled = false;
    setIsLoadingVerses(true);

    loadBibleChapterVerses(selectedBook, selectedChapter, selectedTranslation)
      .then((loaded) => {
        if (!isCancelled) {
          if (loaded && loaded.length > 0) {
            setApiVerses(loaded);
          } else {
            setApiVerses(null);
          }
          setIsLoadingVerses(false);
        }
      })
      .catch((err) => {
        if (!isCancelled) {
          console.error('[BibleReaderView] loadBibleChapterVerses error:', err);
          setApiVerses(null);
          setIsLoadingVerses(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [selectedBook, selectedChapter, selectedTranslation]);

  const verses = React.useMemo(() => {
    if (apiVerses && apiVerses.length > 0) {
      return apiVerses;
    }
    if (SAMPLE_VERSES_CHAPTER[key]) {
      return SAMPLE_VERSES_CHAPTER[key];
    }
    const count = getChapterVerseCount(selectedBook, selectedChapter);
    const generated = [];
    for (let i = 1; i <= count; i++) {
      generated.push({
        verse: i,
        text: isLoadingVerses
          ? `${selectedBook} ${selectedChapter}장 ${i}절 말씀을 불러오고 있습니다...`
          : `${selectedBook} ${selectedChapter}장 ${i}절 말씀입니다.`,
      });
    }
    return generated;
  }, [apiVerses, key, selectedBook, selectedChapter, isLoadingVerses]);

  const handleToggleVerseRead = (v: number) => {
    toggleVerseCompleted(selectedBook, selectedChapter, v);
    setCompletedVerses(getCompletedVerses());
    setCompletedChapters(getCompletedChapters());
  };

  const handleToggleCompleteAllChapterVerses = () => {
    toggleChapterVersesCompleted(selectedBook, selectedChapter, verses.length);
    setCompletedVerses(getCompletedVerses());
    setCompletedChapters(getCompletedChapters());
    const session = getActiveSession();
    if (session && session.email) {
      updateMemberReadingProgress(session.email, selectedBook, selectedChapter);
    }
  };

  const chapterReadVersesCount = verses.filter((v) =>
    completedVerses.has(`${selectedBook}-${selectedChapter}-${v.verse}`)
  ).length;

  // Completion dropdown state & handlers (현재장 완독 / 장 완독 / 전체 완독)
  const currentBookObj = BIBLE_BOOKS.find((b) => b.name === selectedBook);
  const maxChapters = currentBookObj?.chaptersCount || 50;
  const [showCompletionDropdown, setShowCompletionDropdown] = useState(false);
  const [rangeToast, setRangeToast] = useState<string | null>(null);

  // Status checks for currently viewed book and chapter
  const isCurrentChapterDone =
    completedChapters.has(`${selectedBook}-${selectedChapter}`) ||
    (chapterReadVersesCount === verses.length && verses.length > 0) ||
    isChapterFullyRead(selectedBook, selectedChapter, completedVerses);

  const isRangeDone = (() => {
    if (selectedChapter < 1) return false;
    for (let ch = 1; ch <= selectedChapter; ch++) {
      if (
        !completedChapters.has(`${selectedBook}-${ch}`) &&
        !isChapterFullyRead(selectedBook, ch, completedVerses)
      ) {
        return false;
      }
    }
    return true;
  })();

  const isAllBookDone = (() => {
    if (maxChapters < 1) return false;
    for (let ch = 1; ch <= maxChapters; ch++) {
      if (
        !completedChapters.has(`${selectedBook}-${ch}`) &&
        !isChapterFullyRead(selectedBook, ch, completedVerses)
      ) {
        return false;
      }
    }
    return true;
  })();

  // 1. 현재장 완독 토글 (클릭 시 활성화 / 재클릭 시 해제)
  const handleToggleCurrentChapter = () => {
    const willComplete = !isCurrentChapterDone;
    toggleChapterVersesCompleted(selectedBook, selectedChapter, verses.length);
    setCompletedVerses(getCompletedVerses());
    setCompletedChapters(getCompletedChapters());
    const session = getActiveSession();
    if (session && session.email && willComplete) {
      updateMemberReadingProgress(session.email, selectedBook, selectedChapter);
    }
    setRangeToast(
      willComplete
        ? `✓ ${selectedBook} ${selectedChapter}장 완독되었습니다!`
        : `↩️ ${selectedBook} ${selectedChapter}장 완독이 해제되었습니다.`
    );
    setTimeout(() => setRangeToast(null), 3000);
  };

  // 2. 장 완독 토글 (1~현재장 완독: 클릭 시 활성화 / 재클릭 시 해제)
  const handleToggleRangeChapter = () => {
    const willComplete = !isRangeDone;
    const res = markChapterRangeCompleted(selectedBook, 1, selectedChapter, willComplete);
    setCompletedVerses(getCompletedVerses());
    setCompletedChapters(getCompletedChapters());
    const session = getActiveSession();
    if (session && session.email && willComplete) {
      updateMemberReadingProgress(session.email, selectedBook, selectedChapter, res.completedCount);
    }
    setRangeToast(
      willComplete
        ? `📚 ${selectedBook} 1~${selectedChapter}장 (${res.completedCount}개 장) 완독 완료! 읽기표에 반영되었습니다.`
        : `↩️ ${selectedBook} 1~${selectedChapter}장 완독이 해제되었습니다.`
    );
    setTimeout(() => setRangeToast(null), 3500);
  };

  // 3. 전체 완독 토글 (해당 성경 전권 1~maxChapters 완독: 클릭 시 활성화 / 재클릭 시 해제)
  const handleToggleAllBook = () => {
    const willComplete = !isAllBookDone;
    const res = markChapterRangeCompleted(selectedBook, 1, maxChapters, willComplete);
    setCompletedVerses(getCompletedVerses());
    setCompletedChapters(getCompletedChapters());
    const session = getActiveSession();
    if (session && session.email && willComplete) {
      updateMemberReadingProgress(session.email, selectedBook, maxChapters, res.completedCount);
    }
    setRangeToast(
      willComplete
        ? `👑 ${selectedBook} 전권 (1~${maxChapters}장) 전체 완독 완료! 읽기표에 반영되었습니다.`
        : `↩️ ${selectedBook} 전권 완독이 해제되었습니다.`
    );
    setTimeout(() => setRangeToast(null), 3500);
  };

  // Auto-scroll to selected verse and highlight
  useEffect(() => {
    if (selectedVerse && !isRecordingMode) {
      setHighlightedVerses([selectedVerse]);
      const timer = setTimeout(() => {
        const el = document.getElementById(`verse-row-${selectedVerse}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [selectedBook, selectedChapter, selectedVerse, isRecordingMode]);

  // Scroll to active recording verse in recording mode
  useEffect(() => {
    if (isRecordingMode && activeRecordVerse) {
      const el = document.getElementById(`record-verse-row-${activeRecordVerse}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }
  }, [isRecordingMode, activeRecordVerse]);

  // Audio speech synthesis simulation
  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isPlaying, duration]);

  // Recording timer simulation
  useEffect(() => {
    let interval: any;
    if (isRecordingNow) {
      interval = setInterval(() => {
        setRecordDurationSec((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecordingNow]);

  const stopPlayback = () => {
    isPlayingRef.current = false;
    setIsPlaying(false);
    setCurrentSpeakingVerse(null);
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  const handleSelectSpeechRate = (rate: number) => {
    setSpeechRate(rate);
    speechRateRef.current = rate;
    try {
      localStorage.setItem('superbible_speech_rate', String(rate));
    } catch (e) {}

    if (isPreviewPlaying) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsPreviewPlaying(false);
    }

    // 재생 중이면 설정 변경 즉시 현재 절부터 새로운 속도로 실시간 전환
    if (isPlayingRef.current) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      playVerseAtIndex(currentVerseIndexRef.current);
    }
  };

  const handleSelectVoiceType = (type: string) => {
    const normalized = type.includes('여성') ? '여성 (맑고 자연스러운 음성)' : '남성 (자연스러운 중저음)';
    setVoiceType(normalized);
    voiceTypeRef.current = normalized;
    try {
      localStorage.setItem('superbible_voice_type', normalized);
    } catch (e) {}

    if (isPreviewPlaying) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsPreviewPlaying(false);
    }

    if (isPlayingRef.current) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      playVerseAtIndex(currentVerseIndexRef.current);
    }
  };

  const handleSelectSpeechPitch = (pitch: number) => {
    setSpeechPitch(pitch);
    speechPitchRef.current = pitch;
    try {
      localStorage.setItem('superbible_speech_pitch', String(pitch));
    } catch (e) {}

    if (isPreviewPlaying) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsPreviewPlaying(false);
    }

    if (isPlayingRef.current) {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      playVerseAtIndex(currentVerseIndexRef.current);
    }
  };

  const playVerseAtIndex = (index: number) => {
    if (!isPlayingRef.current) return;
    if (index >= verses.length) {
      stopPlayback();
      return;
    }

    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    currentVerseIndexRef.current = index;
    const v = verses[index];
    setCurrentSpeakingVerse(v.verse);

    // 몇절 몇절(절 번호)을 제외하고 오직 절 본문 말씀만 자연스럽게 낭독
    const textToRead = v.text;
    const currentVoiceType = voiceTypeRef.current || voiceType;
    const currentRate = speechRateRef.current || speechRate || 1.1;
    const currentPitch = speechPitchRef.current || speechPitch || 0.96;

    // 영어 낭독 여부 판별 (NIV, 킹제임스 KJV 또는 영문 텍스트)
    const isEnglish =
      selectedTranslation === 'NIV' ||
      selectedTranslation === '킹제임스' ||
      /^[A-Za-z0-9\s.,'":;!?-]+$/.test(textToRead.trim());

    const profile = getVoiceProfile(currentVoiceType, availableVoices, currentRate, currentPitch, isEnglish);

    // 1. 여성 낭독 음원 (또는 영문에서 고음질 뉴럴 웹 음성 없을 때 Google Natural Stream 사용)
    if (currentVoiceType.includes('여성') || (isEnglish && !profile.isNatural)) {
      // 1순위: 브라우저에 고음질 뉴럴 보이스가 있으면 Web Speech로 재생
      if (profile.voice && profile.isNatural) {
        const utterance = new SpeechSynthesisUtterance(textToRead);
        utterance.lang = isEnglish ? 'en-US' : 'ko-KR';
        utterance.voice = profile.voice;
        utterance.pitch = profile.pitch;
        utterance.rate = profile.rate;

        utterance.onend = () => {
          if (isPlayingRef.current) {
            setTimeout(() => {
              if (isPlayingRef.current) playVerseAtIndex(index + 1);
            }, profile.pauseMs);
          }
        };

        utterance.onerror = (err) => {
          console.warn('Speech error at verse', v.verse, err);
          if (isPlayingRef.current) {
            setTimeout(() => {
              if (isPlayingRef.current) playVerseAtIndex(index + 1);
            }, profile.pauseMs);
          }
        };

        window.speechSynthesis.speak(utterance);
        return;
      }

      // 2순위: 브라우저에 구형 기계음(Heami/SAPI Desktop)만 있는 환경일 경우, 기계음을 완전히 배제하고 AI 스튜디오 100% 자연 육성 스트림으로 재생!
      currentAudioRef.current = playNeuralAudio(
        textToRead,
        profile.rate,
        () => {
          if (isPlayingRef.current) {
            setTimeout(() => {
              if (isPlayingRef.current) playVerseAtIndex(index + 1);
            }, profile.pauseMs);
          }
        },
        () => {
          // 네트워크 실패 시 로컬 보이스로 폴백
          if (isPlayingRef.current && profile.voice && 'speechSynthesis' in window) {
            const utterance = new SpeechSynthesisUtterance(textToRead);
            utterance.lang = isEnglish ? 'en-US' : 'ko-KR';
            utterance.voice = profile.voice;
            utterance.pitch = profile.pitch;
            utterance.rate = profile.rate;
            utterance.onend = () => {
              if (isPlayingRef.current) {
                setTimeout(() => {
                  if (isPlayingRef.current) playVerseAtIndex(index + 1);
                }, profile.pauseMs);
              }
            };
            utterance.onerror = () => {
              if (isPlayingRef.current) {
                setTimeout(() => {
                  if (isPlayingRef.current) playVerseAtIndex(index + 1);
                }, profile.pauseMs);
              }
            };
            window.speechSynthesis.speak(utterance);
          } else if (isPlayingRef.current) {
            setTimeout(() => {
              if (isPlayingRef.current) playVerseAtIndex(index + 1);
            }, profile.pauseMs);
          }
        },
        isEnglish ? 'en' : 'ko'
      );
      return;
    }

    // 2. 남성 (자연스러운 중저음 바리톤)
    if (profile.voice && profile.isNatural) {
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.lang = isEnglish ? 'en-US' : 'ko-KR';
      utterance.voice = profile.voice;
      utterance.pitch = profile.pitch;
      utterance.rate = profile.rate;

      utterance.onend = () => {
        if (isPlayingRef.current) {
          setTimeout(() => {
            if (isPlayingRef.current) {
              playVerseAtIndex(index + 1);
            }
          }, profile.pauseMs);
        }
      };

      utterance.onerror = (err) => {
        console.warn('Speech error at verse', v.verse, err);
        if (isPlayingRef.current) {
          setTimeout(() => {
            if (isPlayingRef.current) {
              playVerseAtIndex(index + 1);
            }
          }, profile.pauseMs);
        }
      };

      window.speechSynthesis.speak(utterance);
      return;
    }

    // 남성이지만 브라우저에 구형 기계음(Heami/SAPI Desktop)만 있을 경우 AI 스트림으로 자연스럽게 재생!
    currentAudioRef.current = playNeuralAudio(
      textToRead,
      profile.rate,
      () => {
        if (isPlayingRef.current) {
          setTimeout(() => {
            if (isPlayingRef.current) playVerseAtIndex(index + 1);
          }, profile.pauseMs);
        }
      },
      () => {
        if (isPlayingRef.current && profile.voice && 'speechSynthesis' in window) {
          const utterance = new SpeechSynthesisUtterance(textToRead);
          utterance.lang = isEnglish ? 'en-US' : 'ko-KR';
          utterance.voice = profile.voice;
          utterance.pitch = profile.pitch;
          utterance.rate = profile.rate;
          utterance.onend = () => {
            if (isPlayingRef.current) {
              setTimeout(() => {
                if (isPlayingRef.current) playVerseAtIndex(index + 1);
              }, profile.pauseMs);
            }
          };
          window.speechSynthesis.speak(utterance);
        }
      },
      isEnglish ? 'en' : 'ko'
    );
  };

  const togglePlay = () => {
    if (isPlaying) {
      stopPlayback();
    } else {
      if (currentAudioRef.current) {
        currentAudioRef.current.pause();
        currentAudioRef.current = null;
      }
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      isPlayingRef.current = true;
      setIsPlaying(true);
      // 현재 선택된 절이 있으면 해당 절부터 낭독, 없으면 1절부터 시작
      const startIndex =
        selectedVerse && selectedVerse > 1
          ? Math.max(0, verses.findIndex((v) => v.verse === selectedVerse))
          : 0;
      playVerseAtIndex(startIndex >= 0 ? startIndex : 0);
    }
  };

  const previewVoice = (type: string, rate: number, pitch: number) => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPreviewPlaying(true);

    const isEnglish = selectedTranslation === 'NIV' || selectedTranslation === '킹제임스';
    const sample = isEnglish
      ? 'In the beginning God created the heavens and the earth.'
      : '태초에 하나님이 천지를 창조하시니라.';

    const profile = getVoiceProfile(type, availableVoices, rate, pitch, isEnglish);

    // 1. 고음질 뉴럴 브라우저 음성 지원 시
    if (profile.voice && profile.isNatural) {
      const utterance = new SpeechSynthesisUtterance(sample);
      utterance.lang = isEnglish ? 'en-US' : 'ko-KR';
      utterance.voice = profile.voice;
      utterance.pitch = profile.pitch;
      utterance.rate = profile.rate;
      utterance.onend = () => setIsPreviewPlaying(false);
      utterance.onerror = () => setIsPreviewPlaying(false);
      window.speechSynthesis.speak(utterance);
      return;
    }

    // 2. 브라우저에 구형 기계음만 있거나 뉴럴 보이스 부재 시 AI 스튜디오 자연 음원 스트림 재생
    currentAudioRef.current = playNeuralAudio(
      sample,
      profile.rate,
      () => setIsPreviewPlaying(false),
      () => {
        if ('speechSynthesis' in window && profile.voice) {
          const utterance = new SpeechSynthesisUtterance(sample);
          utterance.lang = isEnglish ? 'en-US' : 'ko-KR';
          utterance.voice = profile.voice;
          utterance.pitch = profile.pitch;
          utterance.rate = profile.rate;
          utterance.onend = () => setIsPreviewPlaying(false);
          utterance.onerror = () => setIsPreviewPlaying(false);
          window.speechSynthesis.speak(utterance);
        } else {
          setIsPreviewPlaying(false);
        }
      },
      isEnglish ? 'en' : 'ko'
    );
  };

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const formatHMS = (sec: number) => {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handlePrevChapter = () => {
    if (selectedChapter > 1) {
      setSelectedChapter((prev) => prev - 1);
      setSelectedVerse(1);
      setActiveRecordVerse(1);
      setCurrentTime(0);
      stopPlayback();
    }
  };

  const handleNextChapter = () => {
    const currentBookObj = BIBLE_BOOKS.find((b) => b.name === selectedBook);
    const maxCh = currentBookObj ? currentBookObj.chaptersCount : 50;
    if (selectedChapter < maxCh) {
      setSelectedChapter((prev) => prev + 1);
      setSelectedVerse(1);
      setActiveRecordVerse(1);
      setCurrentTime(0);
      stopPlayback();
    }
  };

  const handleScrollDown = () => {
    if (contentRef.current) {
      contentRef.current.scrollBy({ top: scrollSpeed * 22, behavior: 'smooth' });
    }
  };

  const handleOpenSelector = (step: 'book' | 'chapter' | 'verse' = 'book') => {
    setSelectorInitialStep(step);
    setShowSelectorModal(true);
  };

  const handleSelectLocation = (book: string, chapter: number, verse: number) => {
    setSelectedBook(book);
    setSelectedChapter(chapter);
    setSelectedVerse(verse);
    setActiveRecordVerse(verse);
    setCurrentTime(0);
    stopPlayback();
  };

  // Recording controls
  const handleToggleRecord = async () => {
    if (isRecordingNow) {
      // Pause or stop current verse take
      setIsRecordingNow(false);
      if (mediaRecorderRef.current) {
        if (mediaRecorderRef.current.state === 'recording') {
          try {
            mediaRecorderRef.current.pause();
          } catch (e) {
            try { mediaRecorderRef.current.stop(); } catch (err) {}
          }
        }
      }
      if (!recordedVerses.includes(activeRecordVerse)) {
        setRecordedVerses((prev) => [...prev, activeRecordVerse]);
      }
      // 녹음한 성경 절이 성경관리 및 통독 데이터에 자동 등록 (이중 등록 불필요)
      try {
        toggleVerseCompleted(selectedBook, selectedChapter, activeRecordVerse);
        setCompletedVerses(getCompletedVerses());
        setCompletedChapters(getCompletedChapters());
        window.dispatchEvent(new CustomEvent('superbible_verse_read_changed'));
      } catch (e) {}

      // If continuous recording, advance to next verse
      if (isContinuousRecording && activeRecordVerse < verses.length) {
        setActiveRecordVerse((prev) => prev + 1);
      }
    } else {
      // Start or Resume recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
        try {
          mediaRecorderRef.current.resume();
          setIsRecordingNow(true);
          return;
        } catch (e) {}
      }

      // Fresh recording session: clear previous chunks and start clean
      audioChunksRef.current = [];
      recordedBlobRef.current = null;

      try {
        // High fidelity microphone constraints (standard hardware native sample rate, clean AEC, NS, AGC)
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        mediaStreamRef.current = stream;

        const preferredMimeTypes = [
          'audio/webm;codecs=opus',
          'audio/webm',
          'audio/ogg;codecs=opus',
          'audio/mp4',
        ];
        const mimeType = preferredMimeTypes.find((m) => MediaRecorder.isTypeSupported(m)) || '';

        const recorder = mimeType
          ? new MediaRecorder(stream, { mimeType, audioBitsPerSecond: 128000 })
          : new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;

        recorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) {
            audioChunksRef.current.push(e.data);
          }
        };

        recorder.onstop = () => {
          if (audioChunksRef.current.length > 0) {
            const finalBlob = new Blob(audioChunksRef.current, {
              type: recorder.mimeType || 'audio/webm',
            });
            recordedBlobRef.current = finalBlob;
            if (recordedUrlRef.current) URL.revokeObjectURL(recordedUrlRef.current);
            recordedUrlRef.current = URL.createObjectURL(finalBlob);
          }
          if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach((track) => track.stop());
            mediaStreamRef.current = null;
          }
        };

        recorder.start(250);
        setIsRecordingNow(true);
      } catch (err) {
        console.warn('Microphone access denied or not supported, using simulated timer', err);
        setIsRecordingNow(true);
      }
    }
  };

  const handleCompleteRecording = async () => {
    setIsRecordingNow(false);

    // Guarantee full recorder stop and finalize all audio chunks
    let rawBlob: Blob | null = null;
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      rawBlob = await new Promise<Blob | null>((resolve) => {
        recorder.onstop = () => {
          const finalBlob = new Blob(audioChunksRef.current, {
            type: recorder.mimeType || 'audio/webm',
          });
          recordedBlobRef.current = finalBlob;
          if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach((track) => track.stop());
            mediaStreamRef.current = null;
          }
          resolve(finalBlob);
        };
        try {
          recorder.stop();
        } catch (e) {
          resolve(recordedBlobRef.current);
        }
      });
    } else {
      rawBlob = recordedBlobRef.current || (audioChunksRef.current.length > 0 ? new Blob(audioChunksRef.current, { type: recorder?.mimeType || 'audio/webm' }) : null);
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        mediaStreamRef.current = null;
      }
    }

    const session = getActiveSession();
    const durationStr = recordDurationSec > 0 ? formatHMS(recordDurationSec) : `${recordedVerses.length * 15 || 45}초`;
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '.');

    // 낭독한 장 범위 계산 (예: 말라기 1~5장 또는 말라기 1장)
    const minCh = Math.min(recordStartChapter, recordEndChapter);
    const maxCh = Math.max(recordStartChapter, recordEndChapter);
    const chapterRangeText = getFormattedPassage(selectedBook, minCh, maxCh);
    const chapterCount = Math.max(1, maxCh - minCh + 1);

    // 1. 고음질 128kbps MP3 변환 (음성 피크 정규화 + 잡음/찌그러짐 완전 제거)
    let finalBlob: Blob | null = rawBlob;
    if (rawBlob && rawBlob.size > 0) {
      try {
        finalBlob = await convertBlobToMp3(rawBlob, 128);
      } catch (convErr) {
        console.warn('MP3 conversion fallback', convErr);
      }
    }

    const finalUrl = finalBlob ? URL.createObjectURL(finalBlob) : (recordedUrlRef.current || null);
    const fileName = `${chapterRangeText}.mp3`;
    const audioFile = finalBlob ? new File([finalBlob], fileName, { type: 'audio/mp3' }) : null;

    const recId = `rec-${Date.now()}`;
    const newRecItem = {
      id: recId,
      title: `${chapterRangeText} 낭독 녹음`,
      verseRef: chapterRangeText,
      duration: durationStr,
      date: dateStr,
      audioBlobUrl: finalUrl || undefined,
    };

    // 영구 재생을 위해 IndexedDB에 MP3 저장
    if (finalBlob) {
      saveAudioToStorage(recId, finalBlob).catch(() => {});
    }

    // 2. 관리자 음원 검수 목록 및 누적 녹음 건수 갱신 (비로그인 상태라도 관리자 검수 목록에 등록)
    const effectiveSession = session || ({
      id: 'yoocomdr57',
      name: '로고스 관리자',
      email: 'yoocomdr57@gmail.com',
      department: '지벳팀',
      role: 'admin',
    } as any);
    addMemberRecordingToAdmin(effectiveSession, newRecItem);

    // 3. 관리자 회원_낭독진도 명부 및 구글 스프레드시트에 즉시 낭독진도 실시간 동기화
    updateMemberReadingProgress(effectiveSession.email, selectedBook, maxCh, chapterCount);

    // 4. 로컬 사용자 녹음 보관함에도 저장
    try {
      const rawUser = localStorage.getItem('superbible_user_recordings_v2');
      const userRecs = rawUser ? JSON.parse(rawUser) : [];
      localStorage.setItem('superbible_user_recordings_v2', JSON.stringify([newRecItem, ...userRecs]));
    } catch (e) {}

    // 5. 낭독한 장 범위의 모든 장과 절을 성경관리 데이터에 완독으로 자동 등록 (이중 등록 완전 제거)
    try {
      markChapterRangeCompleted(selectedBook, minCh, maxCh, true);
      for (let ch = minCh; ch <= maxCh; ch++) {
        addTodayReadChapter(selectedBook, ch);
      }
      setCompletedVerses(getCompletedVerses());
      setCompletedChapters(getCompletedChapters());
      window.dispatchEvent(new CustomEvent('superbible_verse_read_changed'));
      window.dispatchEvent(new CustomEvent('superbible_today_read_changed'));
      window.dispatchEvent(new CustomEvent('superbible_recordings_changed'));
      window.dispatchEvent(new CustomEvent('superbible_members_changed'));
    } catch (e) {}

    // Open Share Modal immediately for seamless Telegram / Team 과제제출방 sharing
    setActiveShareData({
      title: newRecItem.title,
      verseRef: chapterRangeText,
      duration: newRecItem.duration,
      date: newRecItem.date,
      audioBlob: finalBlob,
      audioUrl: finalUrl,
      audioFile: audioFile,
      book: selectedBook,
      chapter: maxCh,
    });
  };

  const filteredVerses = searchQuery.trim()
    ? verses.filter((v) => v.text.toLowerCase().includes(searchQuery.toLowerCase()))
    : verses;

  // ==========================================
  // MODE 1: 성경 낭독 녹음 화면 (Matching User Uploaded Image)
  // ==========================================
  if (isRecordingMode) {
    return (
      <div className="flex-1 flex flex-col h-full bg-white relative overflow-hidden select-none text-slate-800">
        {/* 1. Header (Dark Sage / Olive Green #496557) */}
        <header className="bg-[#496557] text-white px-3 py-2 flex items-center justify-between shadow-md z-30 flex-shrink-0">
          {/* Left: Back button & Book & Chapter and Translation */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => {
                setIsRecordingNow(false);
                if (recordedVerses.length > 0) {
                  for (const vNum of recordedVerses) {
                    toggleVerseCompleted(selectedBook, selectedChapter, vNum);
                  }
                  setCompletedVerses(getCompletedVerses());
                  setCompletedChapters(getCompletedChapters());
                  window.dispatchEvent(new CustomEvent('superbible_verse_read_changed'));
                }
                if (onBack) {
                  onBack();
                } else {
                  setIsRecordingMode(false);
                }
              }}
              className="p-1 hover:bg-white/15 rounded-lg transition cursor-pointer"
              title="뒤로 가기"
            >
              <ChevronLeft className="w-5 h-5 text-white" />
            </button>

            <button
              type="button"
              onClick={() => handleOpenSelector('book')}
              className="flex items-center gap-1 hover:bg-white/10 px-2 py-0.5 rounded-lg transition cursor-pointer"
            >
              <span className="text-[15px] sm:text-base font-extrabold whitespace-nowrap">
                {selectedBook} {selectedChapter}장
              </span>
              <span className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center text-[10px]">
                ▽
              </span>
            </button>

            <button
              type="button"
              onClick={() => setShowTransModal(true)}
              className="flex items-center gap-1 hover:bg-white/10 px-2 py-0.5 rounded-lg transition cursor-pointer"
            >
              <span className="text-[13px] sm:text-sm font-bold whitespace-nowrap">
                {selectedTranslation}
              </span>
              <span className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center text-[10px]">
                ▽
              </span>
            </button>
          </div>

          {/* Right: A 글자 and ✕ Close button */}
          <div className="flex items-center gap-3 text-white">
            <button
              type="button"
              onClick={() => setShowScreenSettings(true)}
              className="flex flex-col items-center justify-center hover:bg-white/15 px-1.5 py-0.5 rounded-lg transition cursor-pointer"
              title="글자 크기 및 화면 설정"
            >
              <span className="text-base font-serif font-black leading-none">A</span>
              <span className="text-[9px] font-medium leading-none mt-0.5">글자</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsRecordingNow(false);
                if (recordedVerses.length > 0) {
                  for (const vNum of recordedVerses) {
                    toggleVerseCompleted(selectedBook, selectedChapter, vNum);
                  }
                  setCompletedVerses(getCompletedVerses());
                  setCompletedChapters(getCompletedChapters());
                  window.dispatchEvent(new CustomEvent('superbible_verse_read_changed'));
                }
                if (onBack) {
                  onBack();
                } else {
                  setIsRecordingMode(false);
                }
              }}
              className="p-1 hover:bg-white/15 rounded-lg transition cursor-pointer"
              title="녹음 모드 종료"
            >
              <X className="w-6 h-6 stroke-[2.2]" />
            </button>
          </div>
        </header>

        {/* 2. Top Notice Banner: "성경낭독녹음 기능을 이용하고 계십니다" & 낭독 본문 뱃지 */}
        <div className="bg-[#f8faf9] border-b border-slate-200/90 px-4 py-2 flex items-center justify-between z-20 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full bg-[#8c6d58] text-white flex items-center justify-center flex-shrink-0 shadow-2xs">
              <Mic className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs sm:text-sm font-bold text-slate-800">
              성경낭독녹음 기능을 이용하고 계십니다
            </span>
          </div>

          <span className="bg-amber-600 text-white px-2.5 py-0.5 rounded-full text-xs font-black shadow-2xs">
            {getFormattedPassage(selectedBook, recordStartChapter, recordEndChapter)}
          </span>
        </div>

        {/* 2-1. 낭독 장 범위 (마지막 낭독한 장 표시 및 조정 바) */}
        <div className="bg-amber-50/95 border-b border-amber-200/90 px-3.5 py-2 flex items-center justify-between z-20 flex-shrink-0 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-amber-950">
            <span className="text-amber-800 font-extrabold text-[12px]">📜 낭독 본문:</span>
            <span className="font-black text-amber-900 bg-amber-200/70 px-2 py-0.5 rounded text-[12px]">
              {getFormattedPassage(selectedBook, recordStartChapter, recordEndChapter)}
            </span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* 시작 장 */}
            <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-lg px-2 py-0.5 shadow-2xs">
              <span className="text-[10px] text-slate-500 font-medium">시작</span>
              <button
                type="button"
                onClick={() => setRecordStartChapter((p) => Math.max(1, p - 1))}
                className="w-4 h-4 flex items-center justify-center text-slate-700 hover:text-slate-900 font-black cursor-pointer"
                title="시작 장 -1"
              >
                -
              </button>
              <span className="font-black text-amber-900 min-w-[18px] text-center">{recordStartChapter}장</span>
              <button
                type="button"
                onClick={() => setRecordStartChapter((p) => Math.min(recordEndChapter, p + 1))}
                className="w-4 h-4 flex items-center justify-center text-slate-700 hover:text-slate-900 font-black cursor-pointer"
                title="시작 장 +1"
              >
                +
              </button>
            </div>

            <span className="text-amber-700 font-extrabold text-sm">~</span>

            {/* 마지막 낭독한 장 */}
            <div className="flex items-center gap-1 bg-white border border-amber-300 rounded-lg px-2 py-0.5 shadow-2xs">
              <span className="text-[10px] text-slate-500 font-medium">마지막 낭독</span>
              <button
                type="button"
                onClick={() => setRecordEndChapter((p) => Math.max(recordStartChapter, p - 1))}
                className="w-4 h-4 flex items-center justify-center text-slate-700 hover:text-slate-900 font-black cursor-pointer"
                title="마지막 장 -1"
              >
                -
              </button>
              <span className="font-black text-amber-900 min-w-[18px] text-center">{recordEndChapter}장</span>
              <button
                type="button"
                onClick={() => {
                  const maxCh = getBookMaxChapters(selectedBook);
                  setRecordEndChapter((p) => Math.min(maxCh, p + 1));
                }}
                className="w-4 h-4 flex items-center justify-center text-slate-700 hover:text-slate-900 font-black cursor-pointer"
                title="마지막 장 +1"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* 3. Sub-toolbar: < > | 녹음현황·공유 ➦ | 연속 녹음 ON */}
        <div className="bg-white border-b border-slate-200 px-3 py-1.5 flex items-center justify-between text-xs flex-shrink-0 z-20">
          {/* Left Chevrons: navigate active recording verse */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setActiveRecordVerse((prev) => Math.max(1, prev - 1))}
              className="w-7 h-7 flex items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 cursor-pointer"
              title="이전 절 선택"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setActiveRecordVerse((prev) => Math.min(verses.length, prev + 1))}
              className="w-7 h-7 flex items-center justify-center rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 cursor-pointer"
              title="다음 절 선택"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Center: 녹음현황·공유 ➦ */}
          <button
            type="button"
            onClick={() => {
              const minCh = Math.min(recordStartChapter, recordEndChapter);
              const maxCh = Math.max(recordStartChapter, recordEndChapter);
              const chapterRangeText = getFormattedPassage(selectedBook, minCh, maxCh);
              setActiveShareData({
                title: `${chapterRangeText} 낭독 녹음`,
                verseRef: chapterRangeText,
                duration: `${recordDurationSec > 0 ? formatHMS(recordDurationSec) : (recordedVerses.length * 15 || 45) + '초'}`,
                book: selectedBook,
                chapter: maxCh,
              });
            }}
            className="flex items-center gap-1 px-3 py-1 rounded-full border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-[11px] transition shadow-2xs cursor-pointer"
          >
            <span>녹음현황·공유</span>
            <span className="text-[13px]">➦</span>
          </button>

          {/* Right: 연속 녹음 ON/OFF */}
          <button
            type="button"
            onClick={() => setIsContinuousRecording(!isContinuousRecording)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-[11px] transition shadow-2xs cursor-pointer"
          >
            <span>연속 녹음</span>
            <span
              className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded-full text-white ${
                isContinuousRecording ? 'bg-[#dc2626]' : 'bg-slate-400'
              }`}
            >
              {isContinuousRecording ? 'ON' : 'OFF'}
            </span>
          </button>
        </div>

        {/* 4. Verse List Body with Selection Radio Circles */}
        <div
          ref={contentRef}
          className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 smooth-scroll bg-white"
          style={{
            fontFamily:
              fontFamily === '나눔고딕'
                ? "'Nanum Gothic', sans-serif"
                : fontFamily === '나눔명조'
                ? "'Nanum Myeongjo', serif"
                : "'Noto Sans KR', sans-serif",
          }}
        >
          <div className="max-w-2xl mx-auto space-y-3.5">
            {verses.map((v) => {
              const isSelected = activeRecordVerse === v.verse;
              const isRecorded = recordedVerses.includes(v.verse);

              return (
                <div
                  id={`record-verse-row-${v.verse}`}
                  key={v.verse}
                  onClick={() => setActiveRecordVerse(v.verse)}
                  className={`flex items-start gap-3 py-2 px-3 rounded-xl transition cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-50/70 border border-emerald-300 shadow-xs'
                      : 'hover:bg-slate-50'
                  }`}
                >
                  {/* Selection Radio Circle */}
                  <div className="pt-1 flex-shrink-0">
                    <div
                      className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all ${
                        isSelected
                          ? 'border-[#496557] bg-[#496557]'
                          : isRecorded
                          ? 'border-emerald-500 bg-emerald-500'
                          : 'border-slate-300 bg-slate-100'
                      }`}
                    >
                      {isSelected ? (
                        <div className="w-1.5 h-1.5 rounded-full bg-white" />
                      ) : isRecorded ? (
                        <Check className="w-3 h-3 text-white stroke-[3]" />
                      ) : null}
                    </div>
                  </div>

                  {/* Verse Number */}
                  <span className="text-[15px] sm:text-base font-black text-slate-900 select-none min-w-[16px] pt-0.5">
                    {v.verse}
                  </span>

                  {/* Verse Text */}
                  <p
                    className="flex-1 text-slate-800 tracking-tight"
                    style={{
                      fontSize: `${fontSizePt}px`,
                      lineHeight: `${fontSizePt * 1.8}px`,
                      fontWeight: isBold ? 700 : 400,
                    }}
                  >
                    {v.text}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* 5. Audio Recording Bottom Control Bar (Matching User Screenshot) */}
        <div className="bg-[#fcfdfc] border-t border-slate-200 px-4 pt-2.5 pb-3 z-20 flex-shrink-0 shadow-lg">
          {/* Progress Timeline with Calm, Slow, Smooth Movement (장 분량에 맞춘 서서히 자연스러운 진행) */}
          {(() => {
            const totalChaptersCount = Math.max(1, Math.abs(recordEndChapter - recordStartChapter) + 1);
            // 낭독 속도에 맞춘 여유 있는 권장/목표 시간: 최소 5분(300초), 장당 4분(240초) 기준
            // 녹음 시간이 길어지더라도 현재시간 + 180초로 넉넉하게 확장되어 서서히 자연스럽게 진행
            const baselineTargetSec = Math.max(300, totalChaptersCount * 240);
            const targetRecordDuration = Math.max(baselineTargetSec, recordDurationSec + 180);
            const recordingProgressPercent = Math.min(100, (recordDurationSec / targetRecordDuration) * 100);

            return (
              <div className="space-y-1.5 py-1">
                {/* Visual Progress Track with Smooth CSS Animation */}
                <div className="relative w-full h-2.5 bg-slate-200/90 rounded-full overflow-hidden p-0.5 shadow-inner">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ease-out ${
                      isRecordingNow
                        ? 'bg-linear-to-r from-red-500 via-rose-500 to-amber-500 shadow-sm'
                        : 'bg-linear-to-r from-emerald-500 via-teal-500 to-sky-500'
                    }`}
                    style={{
                      width: `${Math.max(1.5, recordingProgressPercent)}%`,
                    }}
                  />
                </div>

                {/* Timestamps & Chapter Range Info */}
                <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-700 px-0.5">
                  <span className="flex items-center gap-1.5 text-slate-800">
                    {isRecordingNow && (
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-red-600" />
                      </span>
                    )}
                    <span>{formatHMS(recordDurationSec)}</span>
                  </span>

                  <span className="text-[11px] font-sans font-black text-amber-900 bg-amber-100/80 px-2 py-0.5 rounded-full">
                    {getFormattedPassage(selectedBook, recordStartChapter, recordEndChapter)} ({totalChaptersCount}개 장)
                  </span>

                  <span className="text-slate-400 font-medium">
                    권장 {formatHMS(targetRecordDuration)}
                  </span>
                </div>
              </div>
            );
          })()}

          {/* Floating Tooltip: "녹음 버튼을 누르시면 N절이 녹음됩니다" */}
          <div className="flex justify-center my-2">
            <div
              className={`text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-md transition-all ${
                isRecordingNow ? 'bg-red-600 animate-pulse' : 'bg-[#4a5568]'
              }`}
            >
              {isRecordingNow
                ? `🔴 ${activeRecordVerse}절 낭독 녹음 중입니다... (터치 시 정지)`
                : `녹음 버튼을 누르시면 ${activeRecordVerse}절이 녹음됩니다`}
            </div>
          </div>

          {/* 3 Main Action Buttons: 전체 재생 | 🎙 (Microphone) | 완료 */}
          <div className="flex items-center justify-around px-4 pt-1">
            {/* 1. 전체 재생 Button */}
            <div className="flex flex-col items-center">
              <button
                type="button"
                onClick={togglePlay}
                className="w-12 h-12 rounded-full border-2 border-slate-600 bg-white hover:bg-slate-50 active:scale-95 flex items-center justify-center text-slate-800 shadow-sm transition cursor-pointer"
                title="전체 재생"
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-slate-800" /> : <Play className="w-5 h-5 fill-slate-800 ml-0.5" />}
              </button>
              <span className="text-[11px] font-bold text-slate-800 mt-1">전체 재생</span>
            </div>

            {/* 2. Main Red Microphone Circle Button */}
            <div className="flex flex-col items-center">
              <button
                type="button"
                onClick={handleToggleRecord}
                className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-xl transition-all cursor-pointer active:scale-90 ${
                  isRecordingNow
                    ? 'bg-red-600 ring-4 ring-red-300 animate-pulse scale-105'
                    : 'bg-[#ef4444] hover:bg-red-600 ring-4 ring-red-100'
                }`}
                title={isRecordingNow ? '녹음 정지' : '녹음 시작'}
              >
                <Mic className="w-8 h-8 stroke-[2.2]" />
              </button>
            </div>

            {/* 3. 완료 Button */}
            <div className="flex flex-col items-center">
              <button
                type="button"
                onClick={handleCompleteRecording}
                className="w-12 h-12 rounded-full bg-[#786455] hover:bg-[#685548] active:scale-95 text-white flex items-center justify-center shadow-sm transition cursor-pointer"
                title="완료 및 저장"
              >
                <Check className="w-6 h-6 stroke-[2.5]" />
              </button>
              <span className="text-[11px] font-bold text-slate-800 mt-1">완료</span>
            </div>
          </div>
        </div>

        {/* Audio Share Modal (Telegram / KakaoTalk / Team 과제제출방) */}
        <AudioShareModal
          isOpen={activeShareData !== null}
          onClose={() => {
            setActiveShareData(null);
            setIsRecordingMode(false);
          }}
          data={activeShareData}
          userName={getActiveSession()?.name || '로고스 관리자'}
        />

        {/* Screen Settings Modal can be opened via 'A 글자' in header */}
        {showScreenSettings && (
          <div
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end animate-in fade-in duration-200"
            onClick={(e) => {
              if (e.target === e.currentTarget) setShowScreenSettings(false);
            }}
          >
            <div className="w-full max-w-lg mx-auto flex justify-end px-5 pb-2">
              <button
                type="button"
                onClick={() => setShowScreenSettings(false)}
                className="text-white hover:text-slate-200 p-1 cursor-pointer transition active:scale-90"
                title="닫기"
              >
                <X className="w-8 h-8 stroke-[2.2]" />
              </button>
            </div>
            <div className="w-full max-w-lg mx-auto bg-white rounded-t-[28px] p-6 sm:p-7 shadow-2xl space-y-6 text-slate-900 animate-in slide-in-from-bottom duration-200 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-[15px] font-bold text-slate-900">폰트변경</span>
                <div className="flex items-center text-[15px]">
                  <button
                    type="button"
                    onClick={() => setFontFamily('기본')}
                    className={`cursor-pointer transition-colors ${
                      fontFamily === '기본' ? 'text-[#0284c7] font-bold' : 'text-slate-800'
                    }`}
                  >
                    기본
                  </button>
                  <span className="text-slate-300 mx-2.5 font-light">|</span>
                  <button
                    type="button"
                    onClick={() => setFontFamily('나눔고딕')}
                    className={`cursor-pointer transition-colors ${
                      fontFamily === '나눔고딕' ? 'text-[#0284c7] font-bold' : 'text-slate-800'
                    }`}
                  >
                    나눔고딕
                  </button>
                  <span className="text-slate-300 mx-2.5 font-light">|</span>
                  <button
                    type="button"
                    onClick={() => setFontFamily('나눔명조')}
                    className={`cursor-pointer transition-colors ${
                      fontFamily === '나눔명조' ? 'text-[#0284c7] font-bold' : 'text-slate-800'
                    }`}
                  >
                    나눔명조
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[15px] font-bold text-slate-900">폰트굵기</span>
                <button
                  type="button"
                  onClick={() => setIsBold(!isBold)}
                  className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors cursor-pointer ${
                    isBold ? 'bg-[#0284c7]' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`inline-block h-6 w-6 transform rounded-full bg-white shadow-md transition-transform ${
                      isBold ? 'translate-x-7' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[15px] font-bold text-slate-900">글자크기</span>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setFontSizePt((prev) => Math.max(12, prev - 1))}
                    className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold active:scale-90 cursor-pointer"
                  >
                    －
                  </button>
                  <div className="w-28 sm:w-36 flex items-center">
                    <input
                      type="range"
                      min={12}
                      max={26}
                      value={fontSizePt}
                      onChange={(e) => setFontSizePt(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0284c7]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setFontSizePt((prev) => Math.min(26, prev + 1))}
                    className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold active:scale-90 cursor-pointer"
                  >
                    ＋
                  </button>
                  <span className="text-[15px] font-bold text-slate-900 min-w-[38px] text-right">
                    {fontSizePt}pt
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ==========================================
  // MODE 2: 일반 성경 본문 화면 (Normal Reader Mode)
  // ==========================================
  return (
    <div
      className={`flex-1 flex flex-col h-full relative overflow-hidden select-none transition-colors duration-200 ${
        isInverted ? 'bg-[#111827] text-slate-100' : 'bg-white text-slate-800'
      }`}
    >
      {/* 장완독 일괄 완료 알림 토스트 */}
      {rangeToast && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 max-w-md w-[92%] bg-slate-900/95 text-white px-4 py-3 rounded-2xl shadow-2xl border border-emerald-500/80 backdrop-blur-md flex items-center justify-between gap-2 animate-in fade-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-black text-emerald-300">
            <span className="text-base">✨</span>
            <span>{rangeToast}</span>
          </div>
          <div className="flex items-center gap-1.5 flex-shrink-0">
            {onGoToChallenge && (
              <button
                type="button"
                onClick={onGoToChallenge}
                className="px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs cursor-pointer shadow-xs active:scale-95 transition"
              >
                읽기표 확인
              </button>
            )}
            <button
              type="button"
              onClick={() => setRangeToast(null)}
              className="text-slate-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* 1. TOP HEADER (Deep Blue Bar #1b64b9) */}
      <header className="bg-[#1b64b9] text-white px-3 py-2 flex items-center justify-between shadow-md z-30 flex-shrink-0">
        {/* Left: Back button & Dropdowns */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Back Button -> Back to previous screen (Challenge, Selector, or Home) */}
          <button
            type="button"
            onClick={() => {
              if (onBack) {
                onBack();
              } else if (onBackToSelector) {
                onBackToSelector();
              } else if (onBackToHome) {
                onBackToHome();
              } else {
                handlePrevChapter();
              }
            }}
            title="뒤로 가기"
            className="p-1 hover:bg-white/15 rounded-lg transition cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5 text-white" />
          </button>

          {/* Book & Chapter Button */}
          <button
            type="button"
            onClick={() => {
              if (onBackToSelector) {
                onBackToSelector();
              } else {
                handleOpenSelector('book');
              }
            }}
            className="flex items-center gap-1 bg-white/10 hover:bg-white/20 active:scale-95 px-2.5 py-1 rounded-full border border-white/20 transition cursor-pointer"
          >
            <span className="text-[13px] sm:text-sm font-bold whitespace-nowrap">
              {selectedBook} {selectedChapter}장
            </span>
            <span className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center text-[10px]">
              ▼
            </span>
          </button>

          {/* Translation Button */}
          <button
            type="button"
            onClick={() => setShowTransModal(true)}
            className="flex items-center gap-1 bg-white/10 hover:bg-white/20 active:scale-95 px-2.5 py-1 rounded-full border border-white/20 transition cursor-pointer"
          >
            <span className="text-[13px] sm:text-sm font-bold whitespace-nowrap">
              {selectedTranslation}
            </span>
            <span className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center text-[10px]">
              ▼
            </span>
          </button>
        </div>

        {/* Right Action Icons: Only 화면설정 & 검색 (원문업로드 removed) */}
        <div className="flex items-center gap-1 sm:gap-2 text-white">
          {/* 화면설정 */}
          <button
            type="button"
            onClick={() => setShowScreenSettings(true)}
            className="flex flex-col items-center justify-center px-1.5 py-0.5 hover:bg-white/15 rounded-lg transition cursor-pointer"
            title="화면 설정"
          >
            <Monitor className="w-4 h-4 text-white" />
            <span className="text-[9px] font-medium leading-tight mt-0.5 text-center">화면설정</span>
          </button>

          {/* 검색 */}
          <button
            type="button"
            onClick={() => setShowSearch(!showSearch)}
            className="flex flex-col items-center justify-center px-1.5 py-0.5 hover:bg-white/15 rounded-lg transition cursor-pointer"
            title="본문 검색"
          >
            <Search className="w-4 h-4 text-white" />
            <span className="text-[9px] font-medium leading-tight mt-0.5 text-center">검색</span>
          </button>
        </div>
      </header>

      {/* 2. SUB-TOOLBAR (Controls & Badges) */}
      <div
        className={`border-b px-3 py-1.5 flex items-center justify-between text-xs flex-shrink-0 z-20 ${
          isInverted ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
        }`}
      >
        {/* Left Quick Navigation Icons */}
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handlePrevChapter}
            title="이전장"
            className={`w-7 h-7 flex items-center justify-center rounded-lg border cursor-pointer ${
              isInverted ? 'border-slate-700 hover:bg-slate-800 text-slate-200' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleNextChapter}
            title="다음장"
            className={`w-7 h-7 flex items-center justify-center rounded-lg border cursor-pointer ${
              isInverted ? 'border-slate-700 hover:bg-slate-800 text-slate-200' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={togglePlay}
            title={isPlaying ? '음성 중지' : '음성 듣기'}
            className={`w-7 h-7 flex items-center justify-center rounded-lg border cursor-pointer transition ${
              isPlaying
                ? 'bg-blue-600 text-white border-blue-600'
                : isInverted
                ? 'border-slate-700 hover:bg-slate-800 text-slate-200'
                : 'border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
          >
            {isPlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleScrollDown}
            title="아래로 스크롤"
            className={`w-7 h-7 flex items-center justify-center rounded-lg border cursor-pointer ${
              isInverted ? 'border-slate-700 hover:bg-slate-800 text-slate-200' : 'border-slate-200 hover:bg-slate-50 text-slate-700'
            }`}
          >
            <ArrowDown className="w-4 h-4" />
          </button>
        </div>

        {/* Center & Right Badges */}
        <div className="flex items-center gap-1.5">
          {/* 선교 헌금 Badge */}
          <button
            type="button"
            onClick={() => setShowOfferingModal(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-50 hover:bg-red-100/80 border border-red-200/80 text-red-600 font-bold text-[11px] transition cursor-pointer"
          >
            <Heart className="w-3 h-3 fill-red-500 text-red-500" />
            <span>선교 헌금 &gt;</span>
          </button>

          {/* 낭독 음원 및 속도 설정 배지 */}
          <button
            type="button"
            onClick={() => setShowVoiceModal(true)}
            title="클릭 시 낭독 음원 및 속도 설정"
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border font-bold text-[11px] transition cursor-pointer hover:opacity-90 active:scale-95 ${
              isInverted ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-slate-100 border-slate-200 text-slate-800'
            }`}
          >
            <span>{voiceType.includes('여성') ? '🌸' : '🎙️'}</span>
            <span>{voiceType.includes('여성') ? '여성(자연음성)' : '남성(중저음)'}</span>
            <span className="text-[10px] text-[#1b64b9] font-black">{speechRate}x</span>
          </button>
        </div>
      </div>

      {/* Search Input Bar */}
      {showSearch && (
        <div
          className={`border-b px-4 py-2 flex items-center gap-2 animate-in slide-in-from-top duration-150 z-20 ${
            isInverted ? 'bg-slate-900 border-slate-800' : 'bg-blue-50/70 border-blue-200'
          }`}
        >
          <Search className="w-4 h-4 text-blue-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="본문 구절 검색 (예: 하나님, 궁창, 빛)"
            className={`flex-1 border rounded-lg px-2.5 py-1 text-xs focus:outline-none ${
              isInverted ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-blue-200 text-slate-900'
            }`}
            autoFocus
          />
          <button type="button" onClick={() => setShowSearch(false)} className="text-slate-400 p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 3. BIBLE VERSES BODY */}
      <div
        ref={contentRef}
        className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 smooth-scroll"
        style={{
          fontFamily:
            fontFamily === '나눔고딕'
              ? "'Nanum Gothic', sans-serif"
              : fontFamily === '나눔명조'
              ? "'Nanum Myeongjo', serif"
              : "'Noto Sans KR', sans-serif",
        }}
      >
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Custom Translation Notice Banner */}
          {selectedTranslation === '킹제임스흠정역' &&
            !isCustomTranslationRegistered(selectedTranslation) && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between text-xs text-amber-950 shadow-xs mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">📖</span>
                  <div>
                    <p className="font-black text-xs text-amber-900">{selectedTranslation} 소장본 등록 안내</p>
                    <p className="text-[10.5px] text-amber-700 font-medium">
                      소장하신 {selectedTranslation} 텍스트 파일(.txt)을 등록하시면 본문이 즉시 반영됩니다.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setTargetUploadVersion(selectedTranslation);
                    setShowUploadModal(true);
                  }}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-black text-[11px] rounded-xl cursor-pointer whitespace-nowrap shadow-xs ml-2"
                >
                  파일 등록
                </button>
              </div>
            )}

          {/* Loading indicator */}
          {isLoadingVerses && (
            <div className="py-2 text-center text-xs text-slate-400 font-medium flex items-center justify-center gap-2">
              <span className="animate-spin text-sm">⏳</span>
              <span>{selectedBook} {selectedChapter}장 ({selectedTranslation}) 본문을 불러오는 중입니다...</span>
            </div>
          )}

          {/* Section banner */}
          {selectedBook === '창세기' && selectedChapter === 1 && (
            <div className="pt-2 pb-1">
              <button
                type="button"
                className="bg-[#3b747c] hover:bg-[#32636a] text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-xs transition cursor-pointer"
              >
                창세기 이해하기
              </button>
              <h3 className={`text-base sm:text-lg font-extrabold mt-3 mb-1 ${isInverted ? 'text-blue-400' : 'text-[#1b64b9]'}`}>
                천지 창조
              </h3>
            </div>
          )}
          {selectedBook === '창세기' && selectedChapter === 2 && (
            <div className="pt-2 pb-1">
              <button
                type="button"
                className="bg-[#3b747c] hover:bg-[#32636a] text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-xs transition cursor-pointer"
              >
                창세기 이해하기
              </button>
              <h3 className={`text-base sm:text-lg font-extrabold mt-3 mb-1 ${isInverted ? 'text-blue-400' : 'text-[#1b64b9]'}`}>
                안식일과 에덴 동산
              </h3>
            </div>
          )}

          {filteredVerses.map((v) => {
            const isHighlighted = highlightedVerses.includes(v.verse);
            const isRead = completedVerses.has(`${selectedBook}-${selectedChapter}-${v.verse}`);
            const isSpeaking = currentSpeakingVerse === v.verse;
            return (
              <div
                id={`verse-row-${v.verse}`}
                key={v.verse}
                onClick={() => {
                  setHighlightedVerses((prev) =>
                    prev.includes(v.verse) ? prev.filter((n) => n !== v.verse) : [...prev, v.verse]
                  );
                }}
                className={`flex items-start gap-3 py-2 px-2.5 rounded-xl transition cursor-pointer ${
                  isSpeaking
                    ? isInverted
                      ? 'bg-blue-950/70 border-2 border-blue-400 shadow-md ring-2 ring-blue-500/30'
                      : 'bg-blue-50/90 border-2 border-[#1b64b9] shadow-sm ring-2 ring-blue-200'
                    : isHighlighted
                    ? isInverted
                      ? 'bg-amber-950/60 border border-amber-500/80 shadow-xs'
                      : 'bg-amber-100/80 border-2 border-amber-400 shadow-sm'
                    : isRead
                    ? isInverted
                      ? 'bg-emerald-950/30 border border-emerald-800/50'
                      : 'bg-emerald-50/40 border border-emerald-200/70'
                    : isInverted
                    ? 'hover:bg-slate-800/60'
                    : 'hover:bg-slate-50'
                }`}
              >
                {/* Verse Number & Speaking Pulsing Indicator (절 앞 원 제거) */}
                <div className="flex items-center gap-1.5 min-w-[24px] pt-0.5 flex-shrink-0">
                  {isSpeaking && (
                    <span className="w-2 h-2 rounded-full bg-[#1b64b9] animate-ping flex-shrink-0" title="현재 낭독 중" />
                  )}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleVerseRead(v.verse);
                    }}
                    title={isRead ? '읽기 완료됨 (클릭 시 취소)' : '클릭 시 읽기 완료 체크'}
                    className={`text-base sm:text-lg font-black select-none cursor-pointer transition active:scale-90 ${
                      isSpeaking
                        ? 'text-[#1b64b9]'
                        : isRead
                        ? 'text-emerald-600'
                        : isInverted
                        ? 'text-amber-400 hover:text-amber-300'
                        : 'text-slate-900 hover:text-emerald-600'
                    }`}
                  >
                    {v.verse}
                  </button>
                </div>

                {/* Verse Text with dynamic font size, weight, and family */}
                <p
                  className={`flex-1 tracking-tight ${isInverted ? 'text-slate-100' : 'text-slate-800'}`}
                  style={{
                    fontSize: `${fontSizePt}px`,
                    lineHeight: `${fontSizePt * 1.8}px`,
                    fontWeight: isBold ? 700 : 400,
                  }}
                >
                  {v.text}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. CHAPTER NAVIGATION ROW (Right above audio player) */}
      <div
        className={`border-t px-4 py-2 flex items-center justify-between z-20 flex-shrink-0 ${
          isInverted ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-white border-slate-100 text-slate-800'
        }`}
      >
        {/* 이전장 */}
        <button
          type="button"
          onClick={handlePrevChapter}
          className="text-xs font-semibold text-slate-400 hover:text-slate-600 transition cursor-pointer"
        >
          &lt; 이전장
        </button>

        {/* 창세기 1장 ∨ (Click opens 3-step selector) */}
        <button
          type="button"
          onClick={() => {
            if (onBackToSelector) {
              onBackToSelector();
            } else {
              handleOpenSelector('chapter');
            }
          }}
          className={`flex items-center gap-1 text-sm font-extrabold hover:underline cursor-pointer ${
            isInverted ? 'text-blue-400' : 'text-[#1b64b9]'
          }`}
        >
          <span>{selectedBook} {selectedChapter}장</span>
          <span className="text-xs">∨</span>
        </button>

        {/* 다음장 > */}
        <button
          type="button"
          onClick={handleNextChapter}
          className="bg-[#1b64b9] hover:bg-blue-700 active:scale-95 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-xs transition cursor-pointer"
        >
          <span>다음장</span>
          <span>&gt;</span>
        </button>
      </div>

      {/* 5. AUDIO PLAYER (Sticky Bottom Bar) */}
      <div
        className={`border-t px-4 py-2.5 z-20 flex-shrink-0 shadow-lg ${
          isInverted ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-[#f8fafc] border-slate-200 text-slate-800'
        }`}
      >
        {/* Timestamp & Reader Voice Badge & 이 장 전체 완독 버튼 */}
        <div className="flex items-center justify-between text-xs gap-2">
          <span className="font-mono text-xs text-slate-500 flex-shrink-0">{formatTime(currentTime)}</span>

          <div className="flex items-center gap-1.5 flex-wrap justify-center">
            {/* 낭독 음원 및 속도 활성화 버튼 (클릭 시 음원 설정) */}
            <button
              type="button"
              onClick={() => setShowVoiceModal(true)}
              title="클릭 시 낭독 음원 및 속도 설정 열기"
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border shadow-2xs flex items-center gap-1.5 transition cursor-pointer hover:opacity-90 active:scale-95 ${
                isInverted
                  ? 'bg-slate-800 text-blue-300 border-slate-700 hover:bg-slate-750'
                  : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100/70'
              }`}
            >
              <span>{voiceType.includes('여성') ? '🌸' : '🎙️'}</span>
              <span>낭독: {voiceType.includes('여성') ? '여성(자연음성)' : '남성(중저음)'}</span>
              <span className="px-1.5 py-0.2 bg-[#1b64b9] text-white rounded-full text-[10px] font-black">
                {speechRate}x
              </span>
            </button>

            {/* 완독 관리 드롭다운 메뉴 (현재장 완독 / 장 완독 / 전체 완독) */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowCompletionDropdown(!showCompletionDropdown)}
                className={`px-2.5 py-0.5 rounded-full text-[11px] font-black transition cursor-pointer shadow-2xs active:scale-95 flex items-center gap-1 ${
                  isCurrentChapterDone || isRangeDone || isAllBookDone
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-500 shadow-sm ring-2 ring-emerald-300/60'
                    : isInverted
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-300'
                }`}
                title="완독 메뉴 열기 (현재장 완독, 장 완독, 전체 완독)"
              >
                {isCurrentChapterDone || isRangeDone || isAllBookDone ? (
                  <>
                    <span>✓</span>
                    <span>
                      {isAllBookDone
                        ? '전권 완독됨'
                        : isRangeDone
                        ? `${selectedChapter}장까지 완독`
                        : `${selectedChapter}장 완독됨`}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="text-slate-400 font-bold">○</span>
                    <span>완독 관리</span>
                  </>
                )}
                <span className="text-[9px] ml-0.5 opacity-80">▾</span>
              </button>

              {/* 드롭다운 팝업 (위로 팝업) */}
              {showCompletionDropdown && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowCompletionDropdown(false)}
                  />

                  <div className="absolute bottom-full right-0 mb-2 w-64 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-2 z-50 animate-in fade-in slide-in-from-bottom duration-150 text-slate-800 dark:text-slate-100">
                    <div className="px-2 py-1.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1">
                        <span>📖</span>
                        <span>완독 관리</span>
                      </span>
                      <span className="text-[10px] text-slate-400">클릭 시 활성화 / 재클릭 시 해제</span>
                    </div>

                    <div className="py-1 space-y-1">
                      {/* 1. 현재장 완독 */}
                      <button
                        type="button"
                        onClick={() => {
                          handleToggleCurrentChapter();
                          setShowCompletionDropdown(false);
                        }}
                        className={`w-full px-2.5 py-2 rounded-xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
                          isCurrentChapterDone
                            ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-100 font-black border border-emerald-200 dark:border-emerald-800'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                              isCurrentChapterDone
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                            }`}
                          >
                            ✓
                          </span>
                          <div>
                            <p className="text-xs font-black">현재장 완독</p>
                            <p className="text-[10px] text-slate-400 font-normal">
                              {selectedBook} {selectedChapter}장만 완독
                            </p>
                          </div>
                        </div>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${
                            isCurrentChapterDone
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                          }`}
                        >
                          {isCurrentChapterDone ? '완독됨 ✓' : '미완독'}
                        </span>
                      </button>

                      {/* 2. 장 완독 */}
                      <button
                        type="button"
                        onClick={() => {
                          handleToggleRangeChapter();
                          setShowCompletionDropdown(false);
                        }}
                        className={`w-full px-2.5 py-2 rounded-xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
                          isRangeDone
                            ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-100 font-black border border-emerald-200 dark:border-emerald-800'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                              isRangeDone
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                            }`}
                          >
                            📚
                          </span>
                          <div>
                            <p className="text-xs font-black">장 완독</p>
                            <p className="text-[10px] text-slate-400 font-normal">
                              1장 ~ {selectedChapter}장 ({selectedChapter}개 장 일괄)
                            </p>
                          </div>
                        </div>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${
                            isRangeDone
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                          }`}
                        >
                          {isRangeDone ? '완독됨 ✓' : '미완독'}
                        </span>
                      </button>

                      {/* 3. 전체 완독 */}
                      <button
                        type="button"
                        onClick={() => {
                          handleToggleAllBook();
                          setShowCompletionDropdown(false);
                        }}
                        className={`w-full px-2.5 py-2 rounded-xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
                          isAllBookDone
                            ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-100 font-black border border-emerald-200 dark:border-emerald-800'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${
                              isAllBookDone
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                            }`}
                          >
                            👑
                          </span>
                          <div>
                            <p className="text-xs font-black">전체 완독</p>
                            <p className="text-[10px] text-slate-400 font-normal">
                              {selectedBook} 1~{maxChapters}장 전권 완독
                            </p>
                          </div>
                        </div>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${
                            isAllBookDone
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                          }`}
                        >
                          {isAllBookDone ? '전권완독 ✓' : '미완독'}
                        </span>
                      </button>
                    </div>

                    {onGoToChallenge && (
                      <div className="pt-1.5 border-t border-slate-100 dark:border-slate-800 text-center">
                        <button
                          type="button"
                          onClick={() => {
                            setShowCompletionDropdown(false);
                            onGoToChallenge();
                          }}
                          className="text-[11px] font-bold text-[#1b64b9] dark:text-blue-400 hover:underline cursor-pointer inline-flex items-center gap-0.5"
                        >
                          <span>내 전체 읽기표 바로가기</span>
                          <span>&gt;</span>
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>

          <span className="font-mono text-xs text-slate-500 flex-shrink-0">{formatTime(duration)}</span>
        </div>

        {/* Progress Timeline Slider */}
        <div className="relative w-full my-2 flex items-center">
          <input
            type="range"
            min={0}
            max={duration}
            value={currentTime}
            onChange={(e) => setCurrentTime(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-300 rounded-lg appearance-none cursor-pointer accent-[#1b64b9]"
          />
        </div>

        {/* Bottom Audio Controls */}
        <div className="flex items-center justify-between pt-1">
          {/* Audio Playback Buttons */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setCurrentTime(Math.max(0, currentTime - 15))}
              className="p-1 text-slate-600 hover:text-black cursor-pointer"
              title="15초 전으로"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            {/* Play/Pause Main Circle */}
            <button
              type="button"
              onClick={togglePlay}
              className="w-10 h-10 rounded-full bg-[#1b64b9] hover:bg-blue-700 active:scale-95 text-white flex items-center justify-center shadow-md transition cursor-pointer"
              title={isPlaying ? '일시 정지' : '재생'}
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white ml-0.5" />}
            </button>

            <button
              type="button"
              onClick={() => setCurrentTime(Math.min(duration, currentTime + 15))}
              className="p-1 text-slate-600 hover:text-black cursor-pointer"
              title="15초 후로"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          {/* Right Action Buttons: 녹음 & 음원 설정 */}
          <div className="flex items-center gap-2">
            {/* 녹음 버튼 -> Activates the new full Recording Mode Screen from uploaded image! */}
            <button
              type="button"
              onClick={() => {
                setActiveRecordVerse(selectedVerse || 1);
                setIsRecordingMode(true);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold transition shadow-2xs cursor-pointer ${
                isInverted ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700' : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-50'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
              <span>녹음</span>
            </button>

            {/* 음원 설정 버튼 */}
            <button
              type="button"
              onClick={() => setShowVoiceModal(true)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold transition shadow-2xs cursor-pointer ${
                isInverted ? 'border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700' : 'border-slate-300 bg-white text-slate-800 hover:bg-slate-50'
              }`}
            >
              음원 설정
            </button>
          </div>
        </div>
      </div>

      {/* 6. FULL 3-STEP BIBLE SELECTOR MODAL (Fallback) */}
      <BibleSelectorModal
        isOpen={showSelectorModal}
        initialBook={selectedBook}
        initialChapter={selectedChapter}
        initialVerse={selectedVerse}
        initialStep={selectorInitialStep}
        onClose={() => setShowSelectorModal(false)}
        onSelectLocation={handleSelectLocation}
      />

      {/* 7. 화면설정 Bottom Sheet (Exact Match to User Uploaded Screenshot) */}
      {showScreenSettings && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex flex-col justify-end animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowScreenSettings(false);
          }}
        >
          {/* Close 'X' Button on top-right above sheet */}
          <div className="w-full max-w-lg mx-auto flex justify-end px-5 pb-2">
            <button
              type="button"
              onClick={() => setShowScreenSettings(false)}
              className="text-white hover:text-slate-200 p-1 cursor-pointer transition active:scale-90"
              title="닫기"
            >
              <X className="w-8 h-8 stroke-[2.2]" />
            </button>
          </div>

          {/* Bottom Sheet Card */}
          <div className="w-full max-w-lg mx-auto bg-white rounded-t-[28px] p-6 sm:p-7 shadow-2xl space-y-6 text-slate-900 animate-in slide-in-from-bottom duration-200 border-t border-slate-100">
            {/* 1. 폰트변경 */}
            <div className="flex items-center justify-between">
              <span className="text-[15px] font-bold text-slate-900">폰트변경</span>
              <div className="flex items-center text-[15px]">
                <button
                  type="button"
                  onClick={() => setFontFamily('기본')}
                  className={`cursor-pointer transition-colors ${
                    fontFamily === '기본' ? 'text-[#0284c7] font-bold' : 'text-slate-800'
                  }`}
                >
                  기본
                </button>
                <span className="text-slate-300 mx-2.5 font-light">|</span>
                <button
                  type="button"
                  onClick={() => setFontFamily('나눔고딕')}
                  className={`cursor-pointer transition-colors ${
                    fontFamily === '나눔고딕' ? 'text-[#0284c7] font-bold' : 'text-slate-800'
                  }`}
                >
                  나눔고딕
                </button>
                <span className="text-slate-300 mx-2.5 font-light">|</span>
                <button
                  type="button"
                  onClick={() => setFontFamily('나눔명조')}
                  className={`cursor-pointer transition-colors ${
                    fontFamily === '나눔명조' ? 'text-[#0284c7] font-bold' : 'text-slate-800'
                  }`}
                >
                  나눔명조
                </button>
              </div>
            </div>

            {/* 2. 폰트굵기 */}
            <div className="flex items-center justify-between">
              <span className="text-[15px] font-bold text-slate-900">폰트굵기</span>
              <button
                type="button"
                onClick={() => setIsBold(!isBold)}
                className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors cursor-pointer ${
                  isBold ? 'bg-[#0284c7]' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`inline-block h-6 w-6 transform rounded-full bg-white shadow-md transition-transform ${
                    isBold ? 'translate-x-7' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* 3. 글자크기 */}
            <div className="flex items-center justify-between">
              <span className="text-[15px] font-bold text-slate-900">글자크기</span>
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setFontSizePt((prev) => Math.max(12, prev - 1))}
                  className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold active:scale-90 cursor-pointer"
                >
                  －
                </button>
                <div className="w-28 sm:w-36 flex items-center">
                  <input
                    type="range"
                    min={12}
                    max={26}
                    value={fontSizePt}
                    onChange={(e) => setFontSizePt(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0284c7]"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setFontSizePt((prev) => Math.min(26, prev + 1))}
                  className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold active:scale-90 cursor-pointer"
                >
                  ＋
                </button>
                <span className="text-[15px] font-bold text-slate-900 min-w-[38px] text-right">
                  {fontSizePt}pt
                </span>
              </div>
            </div>

            {/* 4. 스크롤 속도 */}
            <div>
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <span className="text-[15px] font-bold text-slate-900 leading-tight">스크롤</span>
                  <span className="text-[15px] font-bold text-slate-900 leading-tight">속도</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setScrollSpeed((prev) => Math.max(1, prev - 1))}
                    className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold active:scale-90 cursor-pointer"
                  >
                    －
                  </button>
                  <div className="w-28 sm:w-36 flex items-center">
                    <input
                      type="range"
                      min={1}
                      max={30}
                      value={scrollSpeed}
                      onChange={(e) => setScrollSpeed(Number(e.target.value))}
                      className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-[#0284c7]"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => setScrollSpeed((prev) => Math.min(30, prev + 1))}
                    className="w-7 h-7 rounded-full border border-slate-300 flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold active:scale-90 cursor-pointer"
                  >
                    ＋
                  </button>
                  <span className="text-[15px] font-bold text-slate-900 min-w-[38px] text-right">
                    {scrollSpeed}
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-500 mt-1.5">
                (숫자가 클수록 스크롤 속도가 빨라집니다)
              </p>
            </div>

            {/* 5. 화면 색반전 */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-[15px] font-bold text-slate-900">화면 색반전</span>
              <div className="flex items-center gap-3">
                {/* Light Mode Button (Sun) */}
                <button
                  type="button"
                  onClick={() => setIsInverted(false)}
                  className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    !isInverted
                      ? 'bg-[#0284c7] text-white shadow-md ring-2 ring-blue-300 scale-105'
                      : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                  }`}
                  title="주간 모드 (밝은 화면)"
                >
                  <Sun className="w-6 h-6 fill-amber-300 text-amber-300" />
                </button>

                {/* Dark Mode Button (Moon) */}
                <button
                  type="button"
                  onClick={() => setIsInverted(true)}
                  className={`w-11 h-11 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    isInverted
                      ? 'bg-slate-900 text-amber-300 shadow-md ring-2 ring-amber-400 scale-105'
                      : 'bg-slate-100 text-amber-500 hover:bg-slate-200'
                  }`}
                  title="야간 모드 (색반전 어두운 화면)"
                >
                  <Moon className="w-6 h-6 fill-amber-300 text-amber-300" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Translation Picker */}
      {showTransModal && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowTransModal(false);
          }}
        >
          <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl border border-slate-100 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-black text-slate-900 text-sm sm:text-base">성경 역본 선택</h3>
                <p className="text-[11px] text-slate-500 font-medium mt-0.5">원하시는 성경 번역본을 선택하세요</p>
              </div>
              <button
                type="button"
                onClick={() => setShowTransModal(false)}
                className="w-7 h-7 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 py-3 overflow-y-auto flex-1 text-xs">
              {availableTranslations.map((trans) => {
                const isSelected = selectedTranslation === trans.id;
                const isCustom = trans.isCustom || isCustomTranslationRegistered(trans.id);
                return (
                  <button
                    key={trans.id}
                    type="button"
                    onClick={() => {
                      setSelectedTranslation(trans.id);
                      localStorage.setItem('superbible_selected_translation', trans.id);
                      setShowTransModal(false);
                    }}
                    className={`w-full p-2.5 rounded-xl text-left border flex items-center justify-between transition cursor-pointer ${
                      isSelected
                        ? 'bg-[#1b64b9] text-white border-[#1b64b9] shadow-xs font-black'
                        : 'hover:bg-slate-50 border-slate-200 text-slate-800 font-bold'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span>{trans.name}</span>
                        {isCustom && (
                          <span
                            className={`text-[9.5px] px-1.5 py-0.2 rounded-md font-bold ${
                              isSelected ? 'bg-white/20 text-white' : 'bg-blue-50 text-[#1b64b9]'
                            }`}
                          >
                            소장본
                          </span>
                        )}
                      </div>
                      <p className={`text-[10.5px] mt-0.5 font-normal ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                        {trans.description}
                      </p>
                    </div>
                    {isSelected && <span className="font-bold text-sm">✓</span>}
                  </button>
                );
              })}
            </div>

            {/* Bottom action: Upload custom Bible file */}
            <div className="pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => {
                  setShowTransModal(false);
                  setTargetUploadVersion('킹제임스흠정역');
                  setShowUploadModal(true);
                }}
                className="w-full py-2.5 px-3 bg-slate-900 hover:bg-black text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm cursor-pointer transition"
              >
                <span>➕</span>
                <span>소장 성경 텍스트(.txt) 파일 등록</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Voice and Natural AI TTS Settings */}
      {showVoiceModal && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              if (currentAudioRef.current) {
                currentAudioRef.current.pause();
                currentAudioRef.current = null;
              }
              if (isPreviewPlaying && 'speechSynthesis' in window) {
                window.speechSynthesis.cancel();
                setIsPreviewPlaying(false);
              }
              setShowVoiceModal(false);
            }
          }}
        >
          <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4 text-slate-800">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-xl">🎙️</span>
                <div>
                  <h3 className="font-black text-slate-900 text-sm sm:text-base">
                    낭독 음원 및 AI TTS 설정
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold">
                    기계음을 제거하고 자연스러운 낭독을 제공합니다
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (currentAudioRef.current) {
                    currentAudioRef.current.pause();
                    currentAudioRef.current = null;
                  }
                  if (isPreviewPlaying && 'speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                    setIsPreviewPlaying(false);
                  }
                  setShowVoiceModal(false);
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Voice Type Options */}
            <div>
              <p className="text-xs font-bold text-slate-600 mb-2">1. 낭독 음원 선택</p>
              <div className="space-y-1.5">
                {[
                  {
                    id: '남성 (자연스러운 중저음)',
                    label: '남성 (자연스러운 중저음)',
                    sub: '깊고 편안한 바리톤 울림, 안정감 있는 낭독 (권장)',
                    tag: '남성 바리톤',
                    icon: '🎙️',
                  },
                  {
                    id: '여성 (맑고 자연스러운 음성)',
                    label: '여성 (맑고 자연스러운 음성)',
                    sub: '기계음 없는 100% 맑고 은혜로운 자연 여성 육성 (기계음 절대 차단)',
                    tag: '자연 여성음',
                    icon: '🌸',
                  },
                ].map((item) => {
                  const isSelected = item.id.includes('여성')
                    ? voiceType.includes('여성')
                    : !voiceType.includes('여성');
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectVoiceType(item.id)}
                      className={`w-full p-2.5 rounded-2xl text-left border transition cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-blue-50 border-2 border-[#1b64b9] shadow-xs'
                          : 'hover:bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{item.icon}</span>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <p
                              className={`text-xs font-black ${
                                isSelected ? 'text-[#1b64b9]' : 'text-slate-900'
                              }`}
                            >
                              {item.label}
                            </p>
                            <span
                              className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                                isSelected
                                  ? 'bg-blue-200/80 text-blue-800'
                                  : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {item.tag}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500 font-bold">{item.sub}</p>
                        </div>
                      </div>
                      {isSelected && (
                        <span className="w-5 h-5 rounded-full bg-[#1b64b9] text-white flex items-center justify-center text-xs font-black shadow-xs">
                          ✓
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Speed Control */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-bold text-slate-700">2. 낭독 속도</p>
                <span className="text-xs font-black text-[#1b64b9] bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                  현재 속도: {speechRate}x
                </span>
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                {[
                  { label: '0.9x', sub: '차분하게', rate: 0.9 },
                  { label: '1.0x', sub: '표준', rate: 1.0 },
                  { label: '1.1x', sub: '추천·빠름', rate: 1.1 },
                  { label: '1.2x', sub: '빠르게', rate: 1.2 },
                  { label: '1.35x', sub: '속독', rate: 1.35 },
                ].map((s) => {
                  const isActive = Math.abs(speechRate - s.rate) < 0.03;
                  return (
                    <button
                      key={s.rate}
                      type="button"
                      onClick={() => handleSelectSpeechRate(s.rate)}
                      className={`py-2 px-1 rounded-xl text-center border transition cursor-pointer flex flex-col items-center justify-center ${
                        isActive
                          ? 'bg-[#1b64b9] text-white border-[#1b64b9] shadow-sm ring-2 ring-blue-300 font-black'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700 font-semibold'
                      }`}
                    >
                      <span className="text-xs font-black leading-tight">{s.label}</span>
                      <span
                        className={`text-[10px] mt-0.5 leading-tight ${
                          isActive ? 'text-blue-100 font-bold' : 'text-slate-400'
                        }`}
                      >
                        {s.sub}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Pitch / Tone Control */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-xs font-bold text-slate-600">3. 음성 톤 (저음/표준)</p>
                <span className="text-xs font-black text-[#1b64b9]">
                  {speechPitch <= 0.94 ? '깊은 저음' : speechPitch <= 0.97 ? '부드러운 중저음' : '표준 톤'}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { label: '깊은 저음', pitch: 0.94 },
                  { label: '부드러운 중저음', pitch: 0.96 },
                  { label: '표준 톤', pitch: 1.0 },
                ].map((p) => {
                  const isActive = Math.abs(speechPitch - p.pitch) < 0.01;
                  return (
                    <button
                      key={p.label}
                      type="button"
                      onClick={() => handleSelectSpeechPitch(p.pitch)}
                      className={`py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer ${
                        isActive
                          ? 'bg-[#1b64b9] text-white border-[#1b64b9] shadow-xs ring-2 ring-blue-300 font-black'
                          : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                      }`}
                    >
                      {p.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Voice Info Box */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-[11px] space-y-1.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-slate-700 font-extrabold">
                  <span className="text-emerald-600">●</span>
                  <span>현재 활성 음원:</span>
                  <span className="text-[#1b64b9] font-black">{voiceType}</span>
                </div>
                <span className="text-[10px] text-slate-500 bg-white px-2 py-0.5 rounded-md border border-slate-200 truncate max-w-[140px]">
                  {getVoiceProfile(voiceType, availableVoices, speechRate, speechPitch, selectedTranslation === 'NIV' || selectedTranslation === '킹제임스').engineName}
                </span>
              </div>
              <p className="text-[10px] text-slate-600 font-bold leading-relaxed">
                ✓ {getVoiceProfile(voiceType, availableVoices, speechRate, speechPitch, selectedTranslation === 'NIV' || selectedTranslation === '킹제임스').summary}
              </p>
            </div>

            {/* Preview and Save Action Buttons */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  if (isPreviewPlaying) {
                    if (currentAudioRef.current) {
                      currentAudioRef.current.pause();
                      currentAudioRef.current = null;
                    }
                    if ('speechSynthesis' in window) {
                      window.speechSynthesis.cancel();
                    }
                    setIsPreviewPlaying(false);
                  } else {
                    previewVoice(voiceType, speechRate, speechPitch);
                  }
                }}
                className={`w-full py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-2 border transition cursor-pointer active:scale-95 ${
                  isPreviewPlaying
                    ? 'bg-amber-100 text-amber-900 border-amber-300 animate-pulse'
                    : 'bg-blue-50 hover:bg-blue-100 text-[#1b64b9] border-blue-200'
                }`}
              >
                <span>{isPreviewPlaying ? '⏹ 미리듣기 멈춤' : '▶ 낭독 음원 미리듣기 (1절 시연)'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (currentAudioRef.current) {
                    currentAudioRef.current.pause();
                    currentAudioRef.current = null;
                  }
                  if (isPreviewPlaying && 'speechSynthesis' in window) {
                    window.speechSynthesis.cancel();
                    setIsPreviewPlaying(false);
                  }
                  setShowVoiceModal(false);
                }}
                className="w-full py-2.5 rounded-xl bg-[#1b64b9] hover:bg-blue-700 text-white font-black text-xs shadow-md transition cursor-pointer active:scale-95"
              >
                설정 완료
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: 선교 헌금 Modal */}
      {showOfferingModal && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowOfferingModal(false);
          }}
        >
          <div className="bg-white rounded-2xl p-5 w-full max-w-sm shadow-2xl border text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
              <Heart className="w-6 h-6 fill-red-500" />
            </div>
            <h3 className="text-base font-extrabold text-slate-900 mb-1">SuperBible 사역 선교 헌금</h3>
            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              전 세계 성도들의 말씀 통독과 음성 녹음 사역을 후원해 주셔서 감사합니다.
            </p>
            <div className="p-3 bg-slate-50 rounded-xl border text-xs text-slate-700 text-left mb-4">
              <p className="font-bold text-slate-900">후원 계좌 안내</p>
              <p className="mt-1">농협 351-1234-5678-91 (예금주: 로고스선교회)</p>
            </div>
            <button
              type="button"
              onClick={() => setShowOfferingModal(false)}
              className="w-full py-2.5 rounded-xl bg-[#1b64b9] text-white text-xs font-bold hover:bg-blue-700 transition cursor-pointer"
            >
              확인
            </button>
          </div>
        </div>
      )}

      {/* MODAL: Custom Bible Text File Upload */}
      <CustomBibleUploadModal
        isOpen={showUploadModal}
        defaultTargetVersion={targetUploadVersion}
        onClose={() => setShowUploadModal(false)}
        onSuccess={(newVer) => {
          setAvailableTranslations(getAllAvailableTranslations());
          setSelectedTranslation(newVer);
          localStorage.setItem('superbible_selected_translation', newVer);
        }}
      />
    </div>
  );
};
